/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type TaskCategory = 'AGENT_EXECUTION' | 'SYSTEM_IDLE' | 'UI_AUDIT' | 'CUSTOM';

export type TaskStatus = 'in-progress' | 'to-do' | 'completed';

export interface Task {
  id: string;
  title: string;
  description: string;
  category: TaskCategory;
  categoryLabel?: string;
  status: TaskStatus;
  priority?: 'Low' | 'Medium' | 'High';
  deadline?: string;
  remainingTime?: string;
  assignees?: Array<{
    name: string;
    avatarUrl?: string;
    isAI?: boolean;
  }>;
}

export interface Agent {
  id: string;
  name: string;
  status: 'Active' | 'Idle';
  processedCount: string;
  accuracy: string;
  sparklineData: number[];
  iconType: 'assignment' | 'security' | 'schedule';
}

export type NotificationType = 'recommendation' | 'task' | 'alert';

export interface AppNotification {
  id: string;
  title: string;
  description: string;
  timestamp: string;
  type: NotificationType;
  categoryLabel: string;
  avatarUrl?: string;
  isUnread: boolean;
  actionable?: {
    primaryText: string;
    secondaryText: string;
  };
}

export interface ChatMessage {
  id: string;
  sender: 'assistant' | 'user' | 'system';
  senderLabel: string;
  text: string;
  timestamp: string;
  processingDetails?: {
    title: string;
    riskLevel: 'High Risk' | 'Medium Risk' | 'Low Risk';
    description: string;
    actionLabel: string;
  };
}

export interface DashboardStats {
  globalAccuracy: string;
  uptime: string;
  efficiency: string;
  activeAgentsCount: number;
}
