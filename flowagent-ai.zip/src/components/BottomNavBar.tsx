/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  LayoutDashboard, 
  Workflow, 
  MessageSquare, 
  Bell, 
  Settings 
} from 'lucide-react';

interface BottomNavBarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  unreadCount: number;
}

export default function BottomNavBar({ activeTab, setActiveTab, unreadCount }: BottomNavBarProps) {
  const tabs = [
    { id: 'dashboard', label: 'DASHBOARD', icon: LayoutDashboard },
    { id: 'workflows', label: 'WORKFLOWS', icon: Workflow },
    { id: 'assistant', label: 'ASSISTANT', icon: MessageSquare },
    { 
      id: 'notifications', 
      label: 'ALERTS', 
      icon: Bell, 
      badge: unreadCount > 0 ? unreadCount : undefined 
    },
    { id: 'settings', label: 'SETTINGS', icon: Settings },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 h-20 bg-brand-bg/95 backdrop-blur-xl border-t border-white/10 flex items-center justify-around px-2 z-40">
      {tabs.map((tab) => {
        const IconComponent = tab.icon;
        const isActive = activeTab === tab.id;

        return (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all ${
              isActive 
                ? 'text-brand-secondary bg-brand-secondary/10 font-bold scale-105' 
                : 'text-brand-muted hover:text-brand-text'
            }`}
          >
            <div className="relative">
              <IconComponent size={20} />
              {tab.badge !== undefined && (
                <span className="absolute -top-1.5 -right-1.5 w-2 h-2 bg-brand-secondary rounded-full animate-pulse" />
              )}
            </div>
            <span className="font-mono text-[9px] tracking-wider uppercase">{tab.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
