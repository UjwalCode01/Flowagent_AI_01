/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  LayoutDashboard, 
  Workflow, 
  Cpu, 
  MessageSquare, 
  LineChart, 
  Bell, 
  Sparkles, 
  Settings, 
  LogOut 
} from 'lucide-react';
import { AVATARS } from '../data';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  unreadCount: number;
  onLogout: () => void;
}

export default function Sidebar({ activeTab, setActiveTab, unreadCount, onLogout }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'workflows', label: 'Workflows', icon: Workflow },
    { id: 'agents', label: 'Agents', icon: Cpu },
    { id: 'assistant', label: 'Assistant', icon: MessageSquare },
    { id: 'analytics', label: 'Analytics', icon: LineChart },
    { 
      id: 'notifications', 
      label: 'Notifications', 
      icon: Bell, 
      badge: unreadCount > 0 ? unreadCount : undefined 
    },
    { id: 'innovation', label: 'Innovation', icon: Sparkles },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <aside className="hidden md:flex flex-col fixed inset-y-0 left-0 z-40 w-72 bg-brand-bg/95 border-r border-white/10 backdrop-blur-xl transition-all">
      {/* Brand Header */}
      <div className="p-6 flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <span className="p-1.5 rounded-lg bg-brand-primary/10 border border-brand-primary/20 text-brand-primary animate-pulse">
            <Sparkles size={20} />
          </span>
          <span className="font-display text-2xl font-black text-brand-primary tracking-tight">
            FlowAgent AI
          </span>
        </div>
        
        {/* Profile Card */}
        <div className="flex items-center gap-3 mt-4 p-2 rounded-xl bg-white/5 border border-white/5">
          <div className="relative w-10 h-10 rounded-full bg-brand-primary/20 flex items-center justify-center text-brand-text overflow-hidden">
            <img 
              src={AVATARS.deepNavy} 
              alt="User profile avatar" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-brand-success border-2 border-[#1a2336] rounded-full" />
          </div>
          <div className="flex flex-col min-w-0">
            <span className="font-sans text-sm font-semibold text-brand-text truncate">FlowAgent AI</span>
            <span className="font-mono text-[10px] text-brand-muted truncate">Enterprise Plan</span>
          </div>
        </div>
      </div>

      {/* Navigation menu */}
      <nav className="flex-1 px-4 py-2 space-y-1 overflow-y-auto no-scrollbar">
        {menuItems.map((item) => {
          const IconComponent = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                isActive 
                  ? 'bg-brand-primary/10 text-brand-primary border border-brand-primary/20 font-bold shadow-[0_0_12px_rgba(192,193,255,0.15)]'
                  : 'text-brand-muted hover:text-brand-text hover:bg-white/5 border border-transparent'
              }`}
            >
              <div className="flex items-center gap-3">
                <IconComponent size={18} className={isActive ? 'text-brand-primary' : 'text-brand-muted'} />
                <span className="font-mono text-[12px] uppercase tracking-wide">{item.label}</span>
              </div>
              {item.badge !== undefined && (
                <span className="bg-brand-secondary text-brand-bg px-2 py-0.5 rounded text-[10px] font-mono font-bold animate-pulse">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer / Logout */}
      <div className="p-4 border-t border-white/10">
        <button 
          onClick={onLogout}
          className="flex items-center gap-3 px-4 py-3 w-full text-brand-muted hover:text-brand-error transition-colors rounded-lg hover:bg-brand-error/5 text-sm"
        >
          <LogOut size={18} />
          <span className="font-mono text-[12px] uppercase tracking-wide">Logout Session</span>
        </button>
        <div className="mt-2 text-center">
          <span className="font-mono text-[10px] text-brand-outline">Engine v2.4.0</span>
        </div>
      </div>
    </aside>
  );
}
