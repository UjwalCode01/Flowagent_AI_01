/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Menu, Sparkles, Wand2 } from 'lucide-react';

interface HeaderProps {
  title: string;
  onOptimize: () => void;
  isOptimizing: boolean;
  onOpenMobileMenu?: () => void;
}

export default function Header({ title, onOptimize, isOptimizing, onOpenMobileMenu }: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 flex justify-between items-center w-full px-4 md:px-10 h-20 bg-brand-bg/85 backdrop-blur-md border-b border-white/10 shadow-sm shadow-brand-secondary/5">
      <div className="flex items-center gap-3">
        {onOpenMobileMenu && (
          <button 
            onClick={onOpenMobileMenu}
            className="md:hidden p-1.5 rounded-lg text-brand-muted hover:text-brand-text hover:bg-white/5 transition-all"
          >
            <Menu size={20} />
          </button>
        )}
        <h1 className="font-display text-lg md:text-xl font-bold text-brand-primary tracking-tight">
          {title}
        </h1>
      </div>

      <button
        onClick={onOptimize}
        disabled={isOptimizing}
        className={`relative overflow-hidden bg-brand-primary text-brand-bg px-4 py-2 rounded-lg font-mono text-[12px] font-bold tracking-wider flex items-center gap-2 hover:opacity-90 active:scale-95 transition-all shadow-lg shadow-brand-primary/20 ${
          isOptimizing ? 'animate-pulse cursor-wait' : ''
        }`}
      >
        <Wand2 size={16} className={isOptimizing ? 'animate-spin' : ''} />
        {isOptimizing ? 'OPTIMIZING...' : 'AI OPTIMIZE'}
        
        {/* Floating background glowing lines */}
        <span className="absolute inset-0 bg-gradient-to-r from-white/15 to-transparent skew-x-12 translate-x-[-100%] hover:translate-x-[100%] transition-transform duration-1000" />
      </button>
    </header>
  );
}
