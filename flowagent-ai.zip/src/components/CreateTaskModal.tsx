/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Plus, Sparkles } from 'lucide-react';
import { Task, TaskCategory, TaskStatus } from '../types';

interface CreateTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (task: Omit<Task, 'id'>) => void;
}

export default function CreateTaskModal({ isOpen, onClose, onSave }: CreateTaskModalProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<TaskCategory>('AGENT_EXECUTION');
  const [status, setStatus] = useState<TaskStatus>('to-do');
  const [priority, setPriority] = useState<'Low' | 'Medium' | 'High'>('Medium');
  const [deadline, setDeadline] = useState('');
  const [remainingTime, setRemainingTime] = useState('');
  const [assigneeName, setAssigneeName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const assignees = assigneeName.trim()
      ? [{ name: assigneeName, isAI: assigneeName.toLowerCase().includes('agent') || assigneeName.toLowerCase().includes('ai') }]
      : [];

    onSave({
      title,
      description,
      category,
      status,
      priority,
      deadline: deadline || undefined,
      remainingTime: remainingTime || undefined,
      assignees,
    });

    // Reset fields
    setTitle('');
    setDescription('');
    setCategory('AGENT_EXECUTION');
    setStatus('to-do');
    setPriority('Medium');
    setDeadline('');
    setRemainingTime('');
    setAssigneeName('');
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div id="create-task-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm"
          />

          {/* Modal Content */}
          <motion.div
            initial={{ scale: 0.95, opacity: 0, y: 15 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.95, opacity: 0, y: 15 }}
            transition={{ type: 'spring', duration: 0.4 }}
            className="relative w-full max-w-lg overflow-hidden rounded-2xl glass-panel p-6 shadow-2xl z-10"
          >
            {/* Top border ambient gradient */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-brand-primary to-brand-secondary" />

            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-brand-primary">
                <Sparkles size={18} />
                <h3 className="font-display font-bold text-lg text-brand-text">Initialize New Workflow</h3>
              </div>
              <button
                onClick={onClose}
                className="p-1 rounded-lg text-brand-muted hover:text-brand-text hover:bg-white/10 transition-all"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Title */}
              <div>
                <label className="block text-xs font-semibold text-brand-muted uppercase tracking-wider mb-1">
                  Workflow Name *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. API Gateway Authentication Setup"
                  className="w-full h-10 bg-brand-bg/80 border border-white/10 rounded-lg px-3 text-brand-text placeholder:text-brand-outline/50 focus:outline-none focus:border-brand-secondary focus:ring-1 focus:ring-brand-secondary/30 transition-all text-sm"
                />
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold text-brand-muted uppercase tracking-wider mb-1">
                  Description
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe the parameters and goals of this workflow..."
                  rows={3}
                  className="w-full bg-brand-bg/80 border border-white/10 rounded-lg p-3 text-brand-text placeholder:text-brand-outline/50 focus:outline-none focus:border-brand-secondary focus:ring-1 focus:ring-brand-secondary/30 transition-all text-sm resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                {/* Category */}
                <div>
                  <label className="block text-xs font-semibold text-brand-muted uppercase tracking-wider mb-1">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as TaskCategory)}
                    className="w-full h-10 bg-[#171f33] border border-white/10 rounded-lg px-2 text-brand-text focus:outline-none focus:border-brand-secondary text-sm"
                  >
                    <option value="AGENT_EXECUTION">Agent Execution</option>
                    <option value="SYSTEM_IDLE">System Idle</option>
                    <option value="UI_AUDIT">UI Audit</option>
                    <option value="CUSTOM">Custom Workflow</option>
                  </select>
                </div>

                {/* Status Column */}
                <div>
                  <label className="block text-xs font-semibold text-brand-muted uppercase tracking-wider mb-1">
                    Initial Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as TaskStatus)}
                    className="w-full h-10 bg-[#171f33] border border-white/10 rounded-lg px-2 text-brand-text focus:outline-none focus:border-brand-secondary text-sm"
                  >
                    <option value="to-do">To Do</option>
                    <option value="in-progress">In Progress</option>
                    <option value="completed">Completed</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                {/* Priority */}
                <div>
                  <label className="block text-xs font-semibold text-brand-muted uppercase tracking-wider mb-1">
                    Priority
                  </label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as 'Low' | 'Medium' | 'High')}
                    className="w-full h-10 bg-[#171f33] border border-white/10 rounded-lg px-2 text-brand-text focus:outline-none focus:border-brand-secondary text-sm"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                  </select>
                </div>

                {/* Deadline */}
                <div>
                  <label className="block text-xs font-semibold text-brand-muted uppercase tracking-wider mb-1">
                    Deadline (e.g. Oct 25)
                  </label>
                  <input
                    type="text"
                    value={deadline}
                    onChange={(e) => setDeadline(e.target.value)}
                    placeholder="e.g. Oct 25"
                    className="w-full h-10 bg-brand-bg/80 border border-white/10 rounded-lg px-3 text-brand-text placeholder:text-brand-outline/50 focus:outline-none focus:border-brand-secondary text-sm"
                  />
                </div>

                {/* Remaining Time */}
                <div>
                  <label className="block text-xs font-semibold text-brand-muted uppercase tracking-wider mb-1">
                    Time (e.g. 2h rem.)
                  </label>
                  <input
                    type="text"
                    value={remainingTime}
                    onChange={(e) => setRemainingTime(e.target.value)}
                    placeholder="e.g. 5h rem."
                    className="w-full h-10 bg-brand-bg/80 border border-white/10 rounded-lg px-3 text-brand-text placeholder:text-brand-outline/50 focus:outline-none focus:border-brand-secondary text-sm"
                  />
                </div>
              </div>

              {/* Assignee Name */}
              <div>
                <label className="block text-xs font-semibold text-brand-muted uppercase tracking-wider mb-1">
                  Assignee/Agent Name
                </label>
                <input
                  type="text"
                  value={assigneeName}
                  onChange={(e) => setAssigneeName(e.target.value)}
                  placeholder="e.g. Sarah Chen or AI Coordinator"
                  className="w-full h-10 bg-brand-bg/80 border border-white/10 rounded-lg px-3 text-brand-text placeholder:text-brand-outline/50 focus:outline-none focus:border-brand-secondary text-sm"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 h-11 border border-white/10 text-brand-text rounded-xl hover:bg-white/5 transition-all text-sm font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 h-11 bg-gradient-to-r from-brand-primary to-brand-secondary text-brand-bg font-bold rounded-xl active:scale-[0.98] transition-transform text-sm shadow-md shadow-brand-primary/10 flex items-center justify-center gap-1.5"
                >
                  <Plus size={16} />
                  Deploy Workflow
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
