/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Clock, 
  Bot, 
  LineChart, 
  UserPlus, 
  CheckCircle, 
  Zap, 
  ShieldCheck, 
  Network, 
  Server,
  Play,
  Activity
} from 'lucide-react';
import { AVATARS } from '../../data';

export default function InnovationScreen() {
  const [activeStep, setActiveStep] = useState<number>(2); // Default step highlighted
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  // Stepper steps
  const steps = [
    { number: 'Step 01', label: 'Task Delayed', icon: Clock, color: 'text-brand-error border-brand-error bg-brand-error/10', glow: 'shadow-[0_0_15px_rgba(255,180,171,0.2)]' },
    { number: 'Step 02', label: 'AI Detects Delay', icon: Bot, color: 'text-brand-secondary border-brand-secondary bg-brand-secondary/10', glow: 'shadow-[0_0_15px_rgba(76,215,246,0.2)]' },
    { number: 'Step 03', label: 'Risk Analysis', icon: LineChart, color: 'text-brand-tertiary border-brand-tertiary bg-brand-tertiary/10', glow: 'shadow-[0_0_15px_rgba(255,183,131,0.2)]' },
    { number: 'Step 04', label: 'Reassignment', icon: UserPlus, color: 'text-brand-primary border-brand-primary bg-brand-primary/10', glow: 'shadow-[0_0_15px_rgba(192,193,255,0.2)]' },
    { number: 'Success', label: 'Project Healed', icon: CheckCircle, color: 'text-brand-success border-brand-success bg-brand-success/10', glow: 'shadow-[0_0_20px_rgba(16,185,129,0.3)]' },
  ];

  // Simulation runner sequence
  const startSimulation = () => {
    if (isSimulating) return;
    setIsSimulating(true);
    setActiveStep(0);
  };

  useEffect(() => {
    if (!isSimulating) return;
    if (activeStep < 4) {
      const timer = setTimeout(() => {
        setActiveStep(prev => prev + 1);
      }, 1500);
      return () => clearTimeout(timer);
    } else {
      setIsSimulating(false);
    }
  }, [isSimulating, activeStep]);

  return (
    <div className="space-y-6">
      {/* Title block */}
      <section className="flex flex-col gap-1">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-2xl font-bold text-brand-text leading-tight">
            Autonomous <span className="text-brand-secondary">Workflow Remediation</span>
          </h2>
          <button 
            onClick={startSimulation}
            disabled={isSimulating}
            className={`px-3 py-1.5 rounded-lg font-mono text-[11px] font-bold tracking-wider flex items-center gap-1.5 transition-all ${
              isSimulating 
                ? 'bg-brand-success/20 text-brand-success cursor-not-allowed' 
                : 'bg-brand-primary text-brand-bg hover:opacity-95 cursor-pointer'
            }`}
          >
            <Play size={12} className={isSimulating ? 'animate-spin' : ''} />
            {isSimulating ? 'HEALING ACTIVE...' : 'SIMULATE RE-ROUTE'}
          </button>
        </div>
        <p className="font-sans text-sm text-brand-muted mt-1 max-w-xl">
          Witness the power of self-healing systems. When a bottleneck occurs, FlowAgent AI automatically re-routes intelligence and resources to protect project integrity.
        </p>
      </section>

      {/* Visualizer Step Stepper Panel */}
      <div className="glass-panel rounded-xl p-6 relative min-h-[340px] flex items-center justify-center overflow-hidden">
        {/* Background micro grid */}
        <div className="absolute inset-0 opacity-5 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#4cd7f6 1px, transparent 1px)', backgroundSize: '24px 24px' }} />

        {/* Dynamic connection lines layer */}
        <div className="relative z-10 w-full">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative">
            {steps.map((step, idx) => {
              const Icon = step.icon;
              const isSelected = activeStep === idx;
              
              return (
                <React.Fragment key={idx}>
                  {/* Stepper Node Card */}
                  <div 
                    onClick={() => !isSimulating && setActiveStep(idx)}
                    className={`flex flex-col items-center gap-2 text-center z-20 cursor-pointer transition-all duration-300 ${
                      isSelected ? `scale-110 ${step.glow}` : 'opacity-60 scale-95 hover:opacity-100'
                    }`}
                  >
                    <div className={`w-14 h-14 rounded-2xl border flex items-center justify-center transition-all ${step.color} ${
                      isSelected ? 'ring-2 ring-white/10' : ''
                    }`}>
                      <Icon size={26} className={isSelected && idx === 1 ? 'animate-bounce' : ''} />
                    </div>
                    <div>
                      <h4 className={`font-mono text-[9px] uppercase tracking-wider font-bold ${
                        isSelected ? 'text-brand-secondary' : 'text-brand-outline'
                      }`}>
                        {step.number}
                      </h4>
                      <p className="font-display font-semibold text-xs text-brand-text">
                        {step.label}
                      </p>
                    </div>
                  </div>

                  {/* Flow connection line connector */}
                  {idx < steps.length - 1 && (
                    <div className="flex-1 h-1 md:h-1 w-1 md:w-auto relative bg-white/5 rounded-full min-h-[20px] md:min-h-0 overflow-hidden">
                      <div className={`absolute inset-0 bg-gradient-to-r from-transparent via-brand-secondary to-transparent w-[200%] h-full animate-pulse ${
                        activeStep >= idx ? 'opacity-85' : 'opacity-10'
                      }`} style={{ animationDuration: '2s' }} />
                    </div>
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>
      </div>

      {/* Bento statistics panel */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="glass-panel p-4 rounded-xl flex flex-col gap-1.5 border-l-2 border-l-brand-secondary">
          <div className="flex items-center justify-between">
            <span className="font-mono text-[9px] text-brand-secondary uppercase font-bold tracking-wider">AUTONOMY SCORE</span>
            <Zap size={14} className="text-brand-secondary" />
          </div>
          <div className="font-display text-2xl font-bold text-brand-text">98.4%</div>
          <p className="font-sans text-[11px] text-brand-muted">
            Workflows self-corrected without human intervention this quarter.
          </p>
        </div>

        <div className="glass-panel p-4 rounded-xl flex flex-col gap-1.5 border-l-2 border-l-brand-primary">
          <div className="flex items-center justify-between">
            <span className="font-mono text-[9px] text-brand-primary uppercase font-bold tracking-wider">RISK MITIGATION</span>
            <ShieldCheck size={14} className="text-brand-primary" />
          </div>
          <div className="font-display text-2xl font-bold text-brand-text">-42%</div>
          <p className="font-sans text-[11px] text-brand-muted">
            Reduction in missed project deadlines since v2.4 deployment.
          </p>
        </div>

        <div className="glass-panel p-4 rounded-xl flex flex-col gap-1.5 border-l-2 border-l-brand-success">
          <div className="flex items-center justify-between">
            <span className="font-mono text-[9px] text-brand-outline uppercase font-bold tracking-wider">ACTIVE AGENTS</span>
            <Network size={14} className="text-brand-outline" />
          </div>
          <div className="font-display text-2xl font-bold text-brand-text">1,204</div>
          <p className="font-sans text-[11px] text-brand-muted">
            AI agents currently monitoring live enterprise pipelines.
          </p>
        </div>
      </div>

      {/* Infrastructure and metrics details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Diagnostics Card */}
        <div className="glass-panel p-5 rounded-xl flex flex-col gap-4">
          <h3 className="font-display text-sm font-bold text-brand-primary uppercase tracking-wider">
            Heuristic Impact Analysis
          </h3>
          <div className="space-y-3.5">
            <div className="flex justify-between items-center pb-2 border-b border-white/5 text-xs">
              <span className="text-brand-muted">Resource Allocation</span>
              <span className="font-mono text-brand-success font-semibold">+12.5% Efficient</span>
            </div>
            <div className="flex justify-between items-center pb-2 border-b border-white/5 text-xs">
              <span className="text-brand-muted">Latency Reduction</span>
              <span className="font-mono text-brand-secondary font-semibold">-310ms latency</span>
            </div>
            <div className="flex justify-between items-center pb-2 border-b border-white/5 text-xs">
              <span className="text-brand-muted">Bottleneck Prediction</span>
              <span className="font-mono text-brand-tertiary font-semibold">94% Accuracy</span>
            </div>
          </div>
        </div>

        {/* Server status banner */}
        <div className="relative rounded-xl overflow-hidden glass-panel flex flex-col justify-end p-5 h-44">
          <img 
            src={AVATARS.datacenterStatus} 
            alt="Futuristic datacenter status visualization" 
            className="absolute inset-0 w-full h-full object-cover opacity-35"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-brand-bg via-brand-bg/40 to-transparent" />
          <div className="relative z-10 space-y-2">
            <div className="flex items-center gap-1.5 text-xs text-brand-text">
              <Server size={14} className="text-brand-success animate-pulse" />
              <span className="font-semibold">Cloud Infrastructure status: ACTIVE</span>
            </div>
            <div className="flex justify-between items-center font-mono text-[9px] text-brand-outline uppercase tracking-wider">
              <span>All clusters optimal</span>
              <span>Region: US-EAST-1</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
