/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Bell, Sparkles, User, AlertTriangle, CheckCircle, BellOff, Trash2 } from 'lucide-react';
import { AppNotification } from '../../types';

interface NotificationsScreenProps {
  notifications: AppNotification[];
  onMarkAsRead: (id: string) => void;
  onOptimizeNotif: (id: string) => void;
  onDismissNotif: (id: string) => void;
}

export default function NotificationsScreen({ notifications, onMarkAsRead, onOptimizeNotif, onDismissNotif }: NotificationsScreenProps) {
  const [filter, setFilter] = useState<'all' | 'recommendation' | 'task' | 'alert'>('all');

  const filteredNotifs = notifications.filter(n => {
    if (filter === 'all') return true;
    return n.type === filter;
  });

  const getCategoryIcon = (type: string) => {
    switch (type) {
      case 'recommendation':
        return <Sparkles size={14} className="text-brand-secondary" />;
      case 'task':
        return <User size={14} className="text-brand-primary" />;
      default:
        return <AlertTriangle size={14} className="text-brand-warning" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Context */}
      <section className="flex flex-col gap-1">
        <h2 className="font-display text-2xl font-bold text-brand-text">Notifications</h2>
        <p className="font-sans text-sm text-brand-muted mt-1">
          Review real-time AI recommendations, system alerts, and task allocations.
        </p>
      </section>

      {/* Filter Chips row */}
      <div className="flex gap-2 pb-1 overflow-x-auto no-scrollbar">
        {(['all', 'recommendation', 'task', 'alert'] as const).map((opt) => (
          <button
            key={opt}
            onClick={() => setFilter(opt)}
            className={`flex-shrink-0 px-4 py-2 rounded-full font-mono text-[11px] font-bold tracking-wider uppercase transition-all cursor-pointer ${
              filter === opt
                ? 'bg-brand-secondary text-brand-bg shadow-md shadow-brand-secondary/15'
                : 'bg-[#171f33] text-brand-muted hover:bg-white/5 hover:text-brand-text'
            }`}
          >
            {opt === 'all' ? 'All' : opt === 'recommendation' ? 'AI Recommendations' : opt + 's'}
          </button>
        ))}
      </div>

      {/* Notification Stack list */}
      <div className="space-y-4">
        {filteredNotifs.length === 0 ? (
          <div className="py-12 flex flex-col items-center opacity-45 text-center">
            <BellOff size={48} className="text-brand-outline mb-4 animate-bounce" />
            <p className="font-sans text-xs text-brand-muted italic max-w-[240px]">
              You are all caught up for today's automated workflows.
            </p>
          </div>
        ) : (
          filteredNotifs.map((notif) => {
            const isUnread = notif.isUnread;

            return (
              <div key={notif.id} className="space-y-2">
                {/* Category label */}
                <div className="flex items-center gap-1.5 px-1">
                  {getCategoryIcon(notif.type)}
                  <span className={`font-mono text-[9px] uppercase tracking-wider font-bold ${
                    notif.type === 'recommendation' ? 'text-brand-secondary' :
                    notif.type === 'task' ? 'text-brand-primary' : 'text-brand-warning'
                  }`}>
                    {notif.categoryLabel}
                  </span>
                </div>

                {/* Main Notification Card */}
                <div 
                  onClick={() => onMarkAsRead(notif.id)}
                  className={`glass-panel rounded-xl p-4 flex gap-4 transition-all hover:border-white/20 relative cursor-pointer ${
                    isUnread ? 'border-brand-secondary/30 shadow-[0_0_12px_rgba(76,215,246,0.05)]' : ''
                  }`}
                >
                  {/* Left indicator accent strip */}
                  {isUnread && (
                    <div className="absolute left-0 top-0 bottom-0 w-1 bg-brand-secondary rounded-l-xl" />
                  )}

                  {/* Icon or avatar block */}
                  <div className="w-12 h-12 rounded-lg bg-white/5 border border-white/5 flex items-center justify-center flex-shrink-0 overflow-hidden">
                    {notif.avatarUrl ? (
                      <img 
                        src={notif.avatarUrl} 
                        alt="Assignee headshot" 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <Bell size={20} className={
                        notif.type === 'recommendation' ? 'text-brand-secondary' :
                        notif.type === 'task' ? 'text-brand-primary' : 'text-brand-error'
                      } />
                    )}
                  </div>

                  {/* Body content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start gap-2 mb-1">
                      <h4 className="font-display font-semibold text-xs md:text-sm text-brand-text leading-snug">
                        {notif.title}
                      </h4>
                      <span className="font-mono text-[9px] text-brand-outline flex-shrink-0 whitespace-nowrap">
                        {notif.timestamp}
                      </span>
                    </div>
                    <p className="font-sans text-xs text-brand-muted mb-3 leading-relaxed">
                      {notif.description}
                    </p>

                    {/* Conditional Action Triggers */}
                    {notif.actionable ? (
                      <div className="flex gap-2">
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            onOptimizeNotif(notif.id);
                          }}
                          className="bg-brand-primary text-brand-bg px-3 py-1.5 rounded-lg font-mono text-[10px] font-bold tracking-wider hover:opacity-90 transition-all cursor-pointer"
                        >
                          {notif.actionable.primaryText.toUpperCase()}
                        </button>
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            onDismissNotif(notif.id);
                          }}
                          className="border border-white/10 text-brand-muted px-3 py-1.5 rounded-lg font-mono text-[10px] tracking-wider hover:bg-white/5 transition-all cursor-pointer"
                        >
                          {notif.actionable.secondaryText.toUpperCase()}
                        </button>
                      </div>
                    ) : (
                      <div className="flex justify-end">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onDismissNotif(notif.id);
                          }}
                          className="p-1 rounded text-brand-outline hover:text-brand-error hover:bg-white/5 transition-all"
                          title="Remove notification"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
