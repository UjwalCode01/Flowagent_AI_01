/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Task, Agent, AppNotification, ChatMessage, DashboardStats } from './types';

export const AVATARS = {
  sarahLab: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBPsdwoCiaCI6tynAJ9VG9l2BQ4Cw7AdvTMcfmcIPg-uoc-5Fkp8LMUp8XkZoTnxvDrANyQ242xCX4CORHQ_WrJaFc8Ur_S0mb-xJLk7B3yqjnRRUvENCpdy9ALMmbsnRfPFYzTh15GwokH7P_1-_h2KR-tcX8k37bknyNFWKHCcAfxL8VTPkiZbi4CfoBjQXx9tW8aJWfcDT4zFQo_FbGXFfqL_ILTxnQrL0FLKBysab-aSHJhcC61UvdLMB8qxceUCFOW_pI3HF8',
  sarahExecutive: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBQCWNjtbl1E0_7zT4Drs4jsAtXC2HrRi-pJJS_MS48bGtMRmi1-KEGOkAfQvSFgjgCTOVnD0QwlRuqpmXAjUfLvPL1PDRGGec3Qn7GSlLbViNbzK9MMbp6n7nZqVzxfZqt93fXO6quetCd4QgIUBHSJxvu0xUTuxGhLp2H8zpgi1d_gv0xca5F2EOeF_hkauWlEZQOylQjR-K-YyL5tHt4S8lT8FPFVztzvY0zJXS_rXicHx2hLGDF7GD0tN4SUqtP6P_IwcLqjYg',
  neonEngineer: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDEgXP3jeqijFshmNa7U9Tl3YQayMXn0MGSoZdZU9UpHH_mCw3jHDrQtgFpgAGprb_knWTSyRBpGr3FoCk3he0yu5PezzlBz46gFh5FdNodAw0fNrBYVDyBG9RIujcbqYFEvvlEfSfZYCawVl06qPNPbFUdWFxasuMdQDZV6h2XLP3IWcXbYaBLpipicSDqmIPcimDbuvlt-hCykz7uJDzLVyrVqD7WwtE5jADVMM6b1-RWY3WoGO1iLrDOesRD9pk2Ruj_YnLPjHY',
  designerNeon: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB3_9hu1By6eU5LVCgFTJruw2XMlSj4LiIqJJYBL3-j7nK0DXs48AJVwQ7oB4FrmnqC7FY1-FEcoNdxY1PLhftQrRnzpCjDHgZCuRqL0JX2EpmyrxNy9TxTdwEptoK-pnxzSm9LVX98oRJqVlyZoGpGndvWiuGlHUeJ_wjGaLKSX6tm9niamA2n62MiB5baUCnWE1S5rEDvqRh1i8ytqTYLlTPDMS0llW7nz6kgGAvB6OgIomFzcwInm1N3DBeJgpCWkalSZNW2K20',
  executiveOffice: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCr6GXgCBl6xP0bXygGlngqzV5jXRwepJIuLldJXvYoyQtMTDwjn6KzUuaB-bH8fSGaUN_JjhzCCaQ2IyZBnjj3Hnu1dg_3axN2YsbsJvEH_GcRu0Zo64uj4ox2d7NiIY47jZJzdRCGFWL7IPMgxlvBkzRLFgH41CyW3WyabS9Z9vBITJqD_fvxQgX6NHlNbe95V5QOednTjR-LjbpVOormIa_lhaSA8rnqR6KruOTTkJi3o4FJ0kJtpPYYJ666GaXv9rsWyVAwupk',
  charcoalBlazer: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB1OTTCcyrlI9c_vrqcjIUgenB8scRqxkemOLcuXoysYyR6-bIx7qtfsmAjz9AsUNXNUfKk9LZIkDwQIHc_VfwNWkRogJUZgVe2k7Sgs8SxjEzVH-X5HYAQMry1sRJiKlKdHtiGSRkzWK1Bi14ZDmJVqUFcZfHbUvFY6X2h8ipLqausExJcgDuP0t2SLHNZyK8xfBWK2cLAFZDirIecj2DfHpXGzZubWCqlCN5Wftwuuqhqyo0jKOSkv9vBZdRsqRbLjT7Jnloznkc',
  deepNavy: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBi-bx4wdclkmHao4TZL5qsRZ8zBbpIT7qdmkorMn1y2-f4AfVyuV7YG5huG8w4Zf0RtRuTHOMjMlb4J4mJ09wejMZsO_WoSnIlbKCVnMWVcX1qaRW10D2yluqlmaD26nT58-9XXllk_wxBFs3XpefntKPiUSsy9Kw1yyAQejoD_54kbkBIKqJklRN944OXmSEiW5PRkG8l2RpL6EzrXKjqAaclMWeMgirwyYlu8Zs2MmNVA4bOX_tmkWcFmapB4xhSkVjDjdNPm88',
  datacenterStatus: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBOsZ6OdcpA7l5LSDqSVQOervV-eCCy7j4BbFDXgMkR94WFsp38Ex8DH5O9CRuaivVGOwIN-w79mab4WGjO45aguJVGck4h8Iw1c2Yu3DDR2ll7qL60DJEgQ9feCjRJQRKh-32RCTGcyjTcMf0qKWelem-hrxdtZzrbxtbUPXJrWvkYcniN1UiHPPv2Vq93LE3HeqYdTMAFmSWKYMTnAL7O97K_L3KZrKEKTaKLz7etwDJYsk6kRUhejqI0ydnvo4Arm3L6UAZXsCE',
};

export const INITIAL_STATS: DashboardStats = {
  globalAccuracy: '99.2%',
  uptime: '99.9%',
  efficiency: '+24.8%',
  activeAgentsCount: 128,
};

export const INITIAL_TASKS: Task[] = [
  {
    id: 'task-1',
    title: 'Risk Detection Setup',
    description: 'Implementing real-time anomaly detection across transactional nodes using Bayesian inference models.',
    category: 'AGENT_EXECUTION',
    status: 'in-progress',
    remainingTime: '2h rem.',
    assignees: [
      { name: 'Sarah Chen', avatarUrl: AVATARS.sarahLab, isAI: false },
      { name: 'FlowAgent Core', isAI: true },
    ],
  },
  {
    id: 'task-2',
    title: 'Database Optimization',
    description: 'Indexing shard clusters and vacuuming dead tuples in the PostgreSQL production environment.',
    category: 'SYSTEM_IDLE',
    status: 'in-progress',
    remainingTime: 'Pending AI',
    assignees: [
      { name: 'Database Engine', avatarUrl: AVATARS.neonEngineer, isAI: false },
    ],
  },
  {
    id: 'task-3',
    title: 'Frontend Review',
    description: 'Accessibility compliance audit for the v3 dashboard components and design system alignment.',
    category: 'UI_AUDIT',
    status: 'to-do',
    priority: 'Medium',
    deadline: 'Oct 24',
    assignees: [],
  },
];

export const INITIAL_AGENTS: Agent[] = [
  {
    id: 'agent-1',
    name: 'Task Assignment',
    status: 'Active',
    processedCount: '1.2k',
    accuracy: '98%',
    sparklineData: [25, 20, 25, 15, 18, 10, 15, 5, 12, 8, 2],
    iconType: 'assignment',
  },
  {
    id: 'agent-2',
    name: 'Risk Detection',
    status: 'Idle',
    processedCount: '842',
    accuracy: '99.9%',
    sparklineData: [20, 22, 20, 21, 20, 22, 20, 21, 20, 21, 20],
    iconType: 'security',
  },
  {
    id: 'agent-3',
    name: 'Deadline Optimization',
    status: 'Active',
    processedCount: '319',
    accuracy: '94%',
    sparklineData: [15, 10, 20, 5, 18, 12, 25, 10],
    iconType: 'schedule',
  },
];

export const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'notif-1',
    title: 'AI detected a potential delay in Q3 Pipeline',
    description: 'Resource allocation for "Project Titan" is below 40%. FlowAgent suggests reallocating 2 backend agents.',
    timestamp: 'Just now',
    type: 'recommendation',
    categoryLabel: 'AI Recommendation',
    isUnread: true,
    actionable: {
      primaryText: 'Optimize',
      secondaryText: 'Dismiss',
    },
  },
  {
    id: 'notif-2',
    title: 'Task reassigned to Sarah Chen',
    description: 'The "API Security Review" task has been moved from your queue to Sarah Chen for specialized validation.',
    timestamp: '14m ago',
    type: 'task',
    categoryLabel: 'Task Assigned',
    avatarUrl: AVATARS.sarahExecutive,
    isUnread: true,
  },
  {
    id: 'notif-3',
    title: 'Quarterly Compliance Window Closing',
    description: 'FlowAgent reports 4 workflows are missing mandatory audit logs before EOD.',
    timestamp: '2h ago',
    type: 'alert',
    categoryLabel: 'Deadline Alert',
    isUnread: false,
  },
];

export const INITIAL_CHAT_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-1',
    sender: 'assistant',
    senderLabel: 'Assistant',
    text: "Hello. I've successfully synchronized with your Q3 Project Pipeline. I'm ready to run a real-time risk analysis or optimize your team's current distribution. How should we proceed?",
    timestamp: 'Just now',
  },
  {
    id: 'msg-2',
    sender: 'user',
    senderLabel: 'You',
    text: 'Analyze project risks for the Enterprise Migration workflow. Highlight any critical bottlenecks in the next 14 days.',
    timestamp: '2m ago',
  },
  {
    id: 'msg-3',
    sender: 'system',
    senderLabel: 'Processing Data',
    text: '',
    timestamp: 'Just now',
    processingDetails: {
      title: 'Resource Conflict: DevOps Team',
      riskLevel: 'High Risk',
      description: "Analysis indicates a 85% probability of delay due to shared resources with the 'Legacy Bridge' project.",
      actionLabel: 'View Full Report',
    },
  },
];

export const SUGGESTED_PROMPTS = [
  'Analyze project risks',
  'Optimize team workload',
  'Generate summary',
  'Reallocate idle agents',
  'Check system compliance'
];
