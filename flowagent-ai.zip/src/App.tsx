/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Activity, CheckCircle, HelpCircle, X } from 'lucide-react';

// Shared types and data
import { Task, Agent, AppNotification, ChatMessage, DashboardStats, TaskStatus } from './types';
import { 
  INITIAL_TASKS, 
  INITIAL_AGENTS, 
  INITIAL_NOTIFICATIONS, 
  INITIAL_CHAT_MESSAGES, 
  INITIAL_STATS 
} from './data';

// Components
import Sidebar from './components/Sidebar';
import BottomNavBar from './components/BottomNavBar';
import Header from './components/Header';
import CreateTaskModal from './components/CreateTaskModal';

// Screens
import DashboardScreen from './components/screens/DashboardScreen';
import WorkflowsScreen from './components/screens/WorkflowsScreen';
import AgentsScreen from './components/screens/AgentsScreen';
import AssistantScreen from './components/screens/AssistantScreen';
import AnalyticsScreen from './components/screens/AnalyticsScreen';
import NotificationsScreen from './components/screens/NotificationsScreen';
import InnovationScreen from './components/screens/InnovationScreen';
import SettingsScreen from './components/screens/SettingsScreen';
import LoginScreen from './components/screens/LoginScreen';

export default function App() {
  // App-wide Authentication state
  const [isLoggedIn, setIsLoggedIn] = useState(true); // Pre-logged in for instant viewing

  // Core synchronized application states
  const [activeTab, setActiveTab] = useState('workflows');
  const [tasks, setTasks] = useState<Task[]>(INITIAL_TASKS);
  const [agents, setAgents] = useState<Agent[]>(INITIAL_AGENTS);
  const [notifications, setNotifications] = useState<AppNotification[]>(INITIAL_NOTIFICATIONS);
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_CHAT_MESSAGES);
  const [stats, setStats] = useState<DashboardStats>(INITIAL_STATS);

  // Layout UI states
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Custom interactive Toast state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Trigger app-wide custom notification toast
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // 1. AI Optimization action runner
  const handleAIOptimize = () => {
    if (isOptimizing) return;
    setIsOptimizing(true);
    triggerToast('Initiating active pipeline heuristic optimization...');

    setTimeout(() => {
      // a. Boost stats metrics
      setStats(prev => ({
        ...prev,
        efficiency: '+28.4%',
        globalAccuracy: '99.6%',
      }));

      // b. Adjust agents performance
      setAgents(prev => prev.map(agent => ({
        ...agent,
        accuracy: agent.id === 'agent-1' ? '99.5%' : agent.id === 'agent-3' ? '98.2%' : agent.accuracy,
        status: 'Active',
        sparklineData: [...agent.sparklineData.slice(1), 28] // append active point
      })));

      // c. Append system re-alignment chat log
      const optimizeMessage: ChatMessage = {
        id: `msg-opt-${Date.now()}`,
        sender: 'system',
        senderLabel: 'Processing Data',
        text: '',
        timestamp: 'Just now',
        processingDetails: {
          title: 'Infrastructure Re-Aligned Successfully',
          riskLevel: 'Low Risk',
          description: 'Telemetry nodes report cluster re-routing optimal. DevOps resource allocation restored to 85%.',
          actionLabel: 'View Active Sparklines'
        }
      };
      setMessages(prev => [...prev, optimizeMessage]);

      // d. Push new AI recommendation notification
      const optimizeNotif: AppNotification = {
        id: `notif-opt-${Date.now()}`,
        title: 'AI Pipeline Re-balancing Complete',
        description: 'Successfully balanced active heuristic cluster. System integrity checked and verified.',
        timestamp: 'Just now',
        type: 'recommendation',
        categoryLabel: 'AI Recommendation',
        isUnread: true,
      };
      setNotifications(prev => [optimizeNotif, ...prev]);

      setIsOptimizing(false);
      triggerToast('AI Optimize successfully re-routed 3 distributed agents!');
    }, 2000);
  };

  // 2. Chat messaging AI responses dispatcher
  const handleSendMessage = (text: string) => {
    // Append User message
    const userMsg: ChatMessage = {
      id: `msg-u-${Date.now()}`,
      sender: 'user',
      senderLabel: 'You',
      text,
      timestamp: 'Just now',
    };
    setMessages(prev => [...prev, userMsg]);
    setIsTyping(true);

    // Simulated AI timing response
    setTimeout(() => {
      const lowerText = text.toLowerCase();
      let replyText = '';
      let processingDetails;

      if (lowerText.includes('risk') || lowerText.includes('analyze')) {
        replyText = "I've completed a risk assessment scan on your active DevOps workspace clusters. Here is the current diagnostic conflict:";
        processingDetails = {
          title: 'DevOps Resource Allocation Overlap',
          riskLevel: 'High Risk' as const,
          description: "A 85% delay likelihood was flagged on 'Risk Detection Setup' due to overlap with 'Legacy Bridge' integration. Recommend clicking AI Optimize to re-allocate.",
          actionLabel: 'Initiate Auto Re-Route'
        };
      } else if (lowerText.includes('optimize')) {
        replyText = "Initiating real-time re-allocation protocols. One moment while I trace and re-align active heuristic nodes...";
        setTimeout(() => {
          handleAIOptimize();
        }, 500);
      } else if (lowerText.includes('summary')) {
        const inProgressCount = tasks.filter(t => t.status === 'in-progress').length;
        const toDoCount = tasks.filter(t => t.status === 'to-do').length;
        const compCount = tasks.filter(t => t.status === 'completed').length;
        replyText = `### Active Pipeline Summary:\n\n- **In Progress**: ${inProgressCount} workflows running\n- **To Do**: ${toDoCount} pending verification\n- **Completed**: ${compCount} successfully archived\n\nAll clusters are operating at an optimal Global Accuracy of **${stats.globalAccuracy}**.`;
      } else {
        replyText = `I have received your coordinate inquiry regarding: "${text}". I have logged the query to our telemetry files. How else can I assist with your FlowAgent AI roster today?`;
      }

      const botMsg: ChatMessage = {
        id: `msg-b-${Date.now()}`,
        sender: 'assistant',
        senderLabel: 'Assistant',
        text: replyText,
        timestamp: 'Just now',
        processingDetails
      };

      setMessages(prev => [...prev, botMsg]);
      setIsTyping(false);
    }, 1500);
  };

  // 3. Task / Workflow state mutations
  const handleAddTask = (newTask: Omit<Task, 'id'>) => {
    const task: Task = {
      id: `task-${Date.now()}`,
      ...newTask,
    };
    setTasks(prev => [task, ...prev]);
    triggerToast(`Successfully deployed "${task.title}" to active pipeline.`);
  };

  const handleUpdateTaskStatus = (taskId: string, newStatus: TaskStatus) => {
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: newStatus } : t));
    triggerToast('Workflow stage advanced successfully.');
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks(prev => prev.filter(t => t.id !== taskId));
    triggerToast('Workflow node deleted.');
  };

  // 4. Notification actions
  const handleMarkNotifAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isUnread: false } : n));
  };

  const handleDismissNotif = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const handleOptimizeNotif = (id: string) => {
    handleDismissNotif(id);
    handleAIOptimize();
  };

  // 5. Agent status toggles
  const handleToggleAgentStatus = (id: string) => {
    setAgents(prev => prev.map(agent => {
      if (agent.id === id) {
        const nextStatus = agent.status === 'Active' ? 'Idle' : 'Active';
        triggerToast(`${agent.name} is now ${nextStatus.toUpperCase()}.`);
        return { ...agent, status: nextStatus };
      }
      return agent;
    }));
  };

  const handleRefreshTelemetry = (id: string) => {
    triggerToast('Re-aligning telemetry sensors...');
    setAgents(prev => prev.map(agent => {
      if (agent.id === id) {
        const nextAcc = `${(92 + Math.random() * 7.5).toFixed(1)}%`;
        // generate slightly randomized sparkline to signify re-alignment
        const nextSpark = agent.sparklineData.map(v => Math.max(2, Math.min(28, v + (Math.random() > 0.5 ? 4 : -4))));
        return {
          ...agent,
          accuracy: nextAcc,
          sparklineData: nextSpark
        };
      }
      return agent;
    }));
    setTimeout(() => {
      triggerToast('Sensor telemetry re-aligned.');
    }, 800);
  };

  // Unread badge selector
  const unreadCount = notifications.filter(n => n.isUnread).length;

  // Header titles helper
  const getHeaderTitle = () => {
    switch (activeTab) {
      case 'dashboard': return 'Dashboard';
      case 'workflows': return 'Workflows';
      case 'agents': return 'Agents Console';
      case 'assistant': return 'FlowAgent Assistant';
      case 'analytics': return 'Telemetry Analytics';
      case 'notifications': return 'Notifications Inbox';
      case 'innovation': return 'Enterprise Workflow Console';
      case 'settings': return 'Settings Configuration';
      default: return 'FlowAgent AI';
    }
  };

  // Render current selected screen
  const renderScreen = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <DashboardScreen 
            stats={stats} 
            agents={agents} 
            onNavigateToTab={(tab) => setActiveTab(tab)}
            onInitializeAgent={() => setIsCreateModalOpen(true)}
          />
        );
      case 'workflows':
        return (
          <WorkflowsScreen 
            tasks={tasks} 
            onAddTaskClick={() => setIsCreateModalOpen(true)}
            onUpdateTaskStatus={handleUpdateTaskStatus}
            onDeleteTask={handleDeleteTask}
          />
        );
      case 'agents':
        return (
          <AgentsScreen 
            agents={agents} 
            onToggleAgentStatus={handleToggleAgentStatus}
            onRefreshTelemetry={handleRefreshTelemetry}
            onInitializeAgent={() => setIsCreateModalOpen(true)}
          />
        );
      case 'assistant':
        return (
          <AssistantScreen 
            messages={messages} 
            onSendMessage={handleSendMessage} 
            isTyping={isTyping} 
          />
        );
      case 'analytics':
        return <AnalyticsScreen stats={stats} />;
      case 'notifications':
        return (
          <NotificationsScreen 
            notifications={notifications} 
            onMarkAsRead={handleMarkNotifAsRead}
            onDismissNotif={handleDismissNotif}
            onOptimizeNotif={handleOptimizeNotif}
          />
        );
      case 'innovation':
        return <InnovationScreen />;
      case 'settings':
        return <SettingsScreen onLogout={() => setIsLoggedIn(false)} />;
      default:
        return <WorkflowsScreen tasks={tasks} onAddTaskClick={() => setIsCreateModalOpen(true)} onUpdateTaskStatus={handleUpdateTaskStatus} onDeleteTask={handleDeleteTask} />;
    }
  };

  // Login layout vs Authenticated Shell
  if (!isLoggedIn) {
    return <LoginScreen onLoginSuccess={() => setIsLoggedIn(true)} />;
  }

  return (
    <div className="min-h-screen bg-brand-bg text-brand-text font-sans antialiased overflow-x-hidden">
      {/* Background Luminous Aura */}
      <div className="fixed top-[-10%] left-[-10%] w-[500px] h-[500px] bg-brand-primary/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="fixed bottom-[-10%] right-[-10%] w-[500px] h-[500px] bg-brand-secondary/5 rounded-full blur-[120px] pointer-events-none" />

      {/* Main Grid Layout */}
      <div className="flex">
        {/* Desktop Sidebar drawer */}
        <Sidebar 
          activeTab={activeTab} 
          setActiveTab={setActiveTab} 
          unreadCount={unreadCount} 
          onLogout={() => setIsLoggedIn(false)} 
        />

        {/* Dynamic Mobile Sliding Side Drawer */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <>
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.5 }}
                exit={{ opacity: 0 }}
                onClick={() => setMobileMenuOpen(false)}
                className="md:hidden fixed inset-0 bg-black z-40"
              />
              <motion.div 
                initial={{ x: '-100%' }}
                animate={{ x: 0 }}
                exit={{ x: '-100%' }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                className="md:hidden fixed inset-y-0 left-0 w-72 bg-brand-bg/95 z-50 border-r border-white/10"
              >
                <div className="p-4 flex justify-between items-center border-b border-white/5">
                  <span className="font-display text-lg font-black text-brand-primary">FlowAgent Navigation</span>
                  <button onClick={() => setMobileMenuOpen(false)} className="p-1 rounded-lg hover:bg-white/5">
                    <X size={18} />
                  </button>
                </div>
                <div className="p-2 space-y-1">
                  {[
                    { id: 'dashboard', label: 'Dashboard' },
                    { id: 'workflows', label: 'Workflows' },
                    { id: 'agents', label: 'Agents' },
                    { id: 'assistant', label: 'Assistant' },
                    { id: 'analytics', label: 'Analytics' },
                    { id: 'notifications', label: `Notifications (${unreadCount})` },
                    { id: 'innovation', label: 'Innovation' },
                    { id: 'settings', label: 'Settings' }
                  ].map(item => (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveTab(item.id);
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full text-left px-4 py-3 rounded-lg text-xs font-mono font-bold uppercase ${
                        activeTab === item.id ? 'bg-brand-primary/15 text-brand-primary border border-brand-primary/20' : 'text-brand-muted hover:bg-white/5'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* Core Screen Container */}
        <div className="flex-1 min-w-0 md:ml-72 pb-24 md:pb-6">
          {/* Top toolbar Header */}
          <Header 
            title={getHeaderTitle()} 
            onOptimize={handleAIOptimize} 
            isOptimizing={isOptimizing}
            onOpenMobileMenu={() => setMobileMenuOpen(true)}
          />

          {/* Active Canvas wrapper */}
          <main className="px-4 md:px-10 py-6">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.25 }}
              >
                {renderScreen()}
              </motion.div>
            </AnimatePresence>
          </main>
        </div>
      </div>

      {/* Floating toast notification bar */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            className="fixed bottom-24 left-4 right-4 md:left-auto md:right-8 md:bottom-8 z-50 bg-[#171f33]/95 border border-brand-primary/30 p-4 rounded-xl shadow-xl shadow-black/50 max-w-sm flex items-center gap-3"
          >
            <Activity className="text-brand-primary animate-pulse flex-shrink-0" size={18} />
            <span className="font-sans text-xs text-brand-text font-semibold">{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile anchored Bottom navigation rail */}
      <BottomNavBar activeTab={activeTab} setActiveTab={setActiveTab} unreadCount={unreadCount} />

      {/* Modal Dialog for initializing Kanban workflows */}
      <CreateTaskModal 
        isOpen={isCreateModalOpen} 
        onClose={() => setIsCreateModalOpen(false)} 
        onSave={handleAddTask} 
      />
    </div>
  );
}
