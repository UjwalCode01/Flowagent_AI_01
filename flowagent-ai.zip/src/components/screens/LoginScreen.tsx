/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sparkles, Mail, Lock, Eye, EyeOff, ArrowRight } from 'lucide-react';

interface LoginScreenProps {
  onLoginSuccess: () => void;
}

export default function LoginScreen({ onLoginSuccess }: LoginScreenProps) {
  const [email, setEmail] = useState('enterprise@flowagent.ai');
  const [password, setPassword] = useState('password123');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      setError('Please fill in all fields.');
      return;
    }
    setError('');
    setIsLoading(true);

    // Simulate enterprise auth delay
    setTimeout(() => {
      setIsLoading(false);
      onLoginSuccess();
    }, 1200);
  };

  const handleSocialLogin = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLoginSuccess();
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-brand-bg text-brand-text flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Decorative Luminous Orbs */}
      <div className="fixed top-[-10%] right-[-10%] w-[350px] h-[350px] bg-brand-primary/10 rounded-full blur-[100px] pointer-events-none" />
      <div className="fixed bottom-[-10%] left-[-10%] w-[350px] h-[350px] bg-brand-secondary/10 rounded-full blur-[100px] pointer-events-none" />

      {/* Main Authenticator Container */}
      <main className="relative z-10 w-full max-w-md flex flex-col items-center">
        
        {/* Brand Header */}
        <div className="mb-8 flex flex-col items-center text-center animate-in fade-in duration-500">
          <div className="mb-4 flex items-center justify-center p-3 rounded-2xl glass-panel w-16 h-16 border-brand-primary/20 shadow-lg shadow-brand-primary/5">
            <Sparkles className="text-brand-primary" size={32} />
          </div>
          <h1 className="font-display text-3xl font-black text-brand-text tracking-tight mb-2">
            FlowAgent AI
          </h1>
          <p className="font-sans text-sm text-brand-muted max-w-[280px]">
            Automate your enterprise workflows with precision intelligence.
          </p>
        </div>

        {/* Login Form Panel */}
        <div className="w-full glass-panel rounded-2xl p-6 shadow-2xl border-white/10 animate-in fade-in slide-in-from-bottom-6 duration-700">
          <div className="mb-6">
            <h2 className="font-display font-bold text-lg text-brand-text mb-1">
              Welcome Back
            </h2>
            <p className="font-sans text-xs text-brand-muted">
              Enter your credentials to access the console.
            </p>
          </div>

          <form onSubmit={handleSignIn} className="space-y-4">
            {error && (
              <div className="p-3 rounded-lg bg-brand-error/10 border border-brand-error/25 text-brand-error font-sans text-xs">
                {error}
              </div>
            )}

            {/* Email Address */}
            <div className="space-y-1">
              <label className="block font-mono text-[10px] text-brand-outline uppercase tracking-wider pl-1 font-bold">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 text-brand-outline" size={16} />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@company.com"
                  className="w-full h-12 bg-brand-bg border border-white/10 rounded-xl pl-10 pr-4 text-brand-text placeholder:text-brand-outline/30 focus:outline-none focus:border-brand-secondary focus:ring-1 focus:ring-brand-secondary/20 transition-all text-sm"
                />
              </div>
            </div>

            {/* Password */}
            <div className="space-y-1">
              <div className="flex justify-between items-center px-1">
                <label className="font-mono text-[10px] text-brand-outline uppercase tracking-wider font-bold">
                  Password
                </label>
                <a 
                  href="#" 
                  onClick={(e) => { e.preventDefault(); alert('For demo, please log in using the pre-configured password.'); }}
                  className="font-mono text-[10px] text-brand-secondary hover:underline uppercase font-bold"
                >
                  Forgot Password?
                </a>
              </div>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 text-brand-outline" size={16} />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full h-12 bg-brand-bg border border-white/10 rounded-xl pl-10 pr-12 text-brand-text placeholder:text-brand-outline/30 focus:outline-none focus:border-brand-secondary focus:ring-1 focus:ring-brand-secondary/20 transition-all text-sm"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-brand-outline hover:text-brand-text transition-colors"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {/* Submit button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full h-12 bg-gradient-to-r from-[#8083ff] to-[#494bd6] hover:opacity-95 text-white font-bold rounded-xl mt-4 flex items-center justify-center gap-2 active:scale-[0.98] transition-all shadow-lg shadow-brand-primary/10 cursor-pointer disabled:opacity-50"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <span>Sign In</span>
                  <ArrowRight size={16} />
                </>
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="relative flex items-center my-6">
            <div className="flex-grow border-t border-white/5" />
            <span className="flex-shrink mx-4 font-mono text-[9px] text-brand-outline uppercase tracking-wider">
              Or Continue With
            </span>
            <div className="flex-grow border-t border-white/5" />
          </div>

          {/* Social login buttons */}
          <div className="grid grid-cols-2 gap-3">
            <button 
              onClick={handleSocialLogin}
              className="flex items-center justify-center gap-2 h-11 border border-white/10 rounded-xl font-mono text-[11px] text-brand-text hover:bg-white/5 transition-all cursor-pointer"
            >
              <img 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuC5aprH2KaDY_T71jqb3K0xWgEzrdC-BeI8unyh189p1YJ3aB4J1VqTFjyeIdXydY3Tf01Ne5JK_Ov3VWcepRwHn68ibsCFB8I4aFlvhlPN9IeqLh2OAeJ6O0XVNlOS-yxS5pYM5j1wRs3EoOQnX5tSZFoWDk2HVfsWQDS_jFeAtwp7Iuptwyf9IWopVh1YxCp0vaP1D1-OQMAk10JuPwJzvC_dg5DLrkaLk-McD3UBKG7FcxbbMFDtCIaI79Gro08Nd_ltGwFfceA" 
                alt="Google authentication icon" 
                className="w-4 h-4 object-contain"
                referrerPolicy="no-referrer"
              />
              <span>Google</span>
            </button>
            <button 
              onClick={handleSocialLogin}
              className="flex items-center justify-center gap-2 h-11 border border-white/10 rounded-xl font-mono text-[11px] text-brand-text hover:bg-white/5 transition-all cursor-pointer"
            >
              <img 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuCYZNqiD-_rEDhaQWPLf_1J5jOxWukKtTkf-7rUiI9te2eyyKmDLRhxbaR5wM53fZtoXyuENLl6Q88L-8q1TAI6DFYf6F0Ouoxr1FE3Ashjya-GFvdoJ_al4rqxCivl9NoVWouXEA0TSTRv3XJvwmfsvDXKv7STtMwSROvoOqOQj2xDa4DPcghe0d4OVwXt9aeXNlDlBo2cQ0Z8n3hW2yoJXij5YmXA-T6Vn5BaXBzn80_YZtREmi9gF1QFjNnI4RwNgmxn8QHYyP4" 
                alt="GitHub authentication icon" 
                className="w-4 h-4 object-contain"
                referrerPolicy="no-referrer"
              />
              <span>GitHub</span>
            </button>
          </div>
        </div>

        {/* Auth footer links */}
        <footer className="mt-8 text-center animate-in fade-in duration-1000">
          <p className="font-sans text-xs text-brand-muted mb-2">
            Don't have an account? <a href="#" onClick={(e) => { e.preventDefault(); alert('Demo request sent successfully!'); }} className="text-brand-secondary font-bold hover:underline">Request Access</a>
          </p>
          <div className="flex justify-center gap-4">
            <span className="font-mono text-[9px] text-brand-outline hover:text-brand-text transition-colors cursor-pointer">Terms</span>
            <span className="text-white/10">•</span>
            <span className="font-mono text-[9px] text-brand-outline hover:text-brand-text transition-colors cursor-pointer">Privacy Policy</span>
          </div>
          <p className="font-mono text-[9px] text-brand-outline/40 mt-6 uppercase tracking-widest">
            © 2026 FLOWAGENT AI · ENTERPRISE V2.4.0
          </p>
        </footer>
      </main>
    </div>
  );
}
