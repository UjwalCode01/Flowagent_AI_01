/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Bot, Cpu, Clock, RefreshCw, Sparkles, Sliders, Play, Pause, ChevronRight } from 'lucide-react';
import { Agent } from '../../types';

interface AgentsScreenProps {
  agents: Agent[];
  onToggleAgentStatus: (agentId: string) => void;
  onRefreshTelemetry: (agentId: string) => void;
  onInitializeAgent: () => void;
}

export default function AgentsScreen({ agents, onToggleAgentStatus, onRefreshTelemetry, onInitializeAgent }: AgentsScreenProps) {
  return (
    <div className="space-y-6">
      {/* Agents Intro banner */}
      <section className="flex flex-col gap-1">
        <h2 className="font-display text-2xl font-bold text-brand-text leading-tight">
          AI Agent <span className="text-brand-secondary">Management</span>
        </h2>
        <p className="font-sans text-sm text-brand-muted mt-1 max-w-xl">
          Track individual agent accuracies, status, and telemetry nodes. Use toggles to coordinate idle pipelines or optimize processing paths.
        </p>
      </section>

      {/* Agents Grid list */}
      <div className="space-y-4">
        {agents.map((agent) => {
          const isTaskAssign = agent.iconType === 'assignment';
          const isRiskDetect = agent.iconType === 'security';
          const isDeadlineOpt = agent.iconType === 'schedule';
          const isActive = agent.status === 'Active';

          return (
            <div 
              key={agent.id}
              className={`glass-card p-5 rounded-xl flex flex-col gap-4 relative overflow-hidden transition-all duration-300 ${
                isActive ? 'border-brand-primary/30 shadow-[0_0_15px_rgba(192,193,255,0.1)]' : ''
              }`}
            >
              {/* Sparkline background glow on active */}
              {isActive && (
                <div className="absolute inset-0 bg-gradient-to-r from-brand-primary/5 via-transparent to-transparent pointer-events-none" />
              )}

              {/* Header telemetry and toggle actions */}
              <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 z-10">
                <div className="flex items-center gap-3">
                  <div className={`p-2.5 rounded-xl border ${
                    isTaskAssign ? 'bg-brand-primary/10 border-brand-primary/20 text-brand-primary' :
                    isRiskDetect ? 'bg-brand-error/10 border-brand-error/20 text-brand-error' :
                    'bg-brand-secondary/10 border-brand-secondary/20 text-brand-secondary'
                  }`}>
                    {isTaskAssign && <Bot size={20} />}
                    {isRiskDetect && <Cpu size={20} />}
                    {isDeadlineOpt && <Clock size={20} />}
                  </div>
                  <div>
                    <h3 className="font-display font-semibold text-brand-text text-base">{agent.name}</h3>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-brand-primary animate-ping' : 'bg-brand-outline'}`} />
                      <span className="font-mono text-[10px] text-brand-outline uppercase font-bold tracking-wider">
                        {agent.status} • Mode: Heuristic
                      </span>
                    </div>
                  </div>
                </div>

                {/* Inline operational triggers */}
                <div className="flex items-center gap-2">
                  {/* Refresh Telemetry */}
                  <button
                    onClick={() => onRefreshTelemetry(agent.id)}
                    className="p-2 rounded-lg bg-white/5 border border-white/5 text-brand-muted hover:text-brand-secondary hover:bg-white/10 transition-all flex items-center gap-1.5 text-xs font-mono"
                    title="Refresh telemetry stream"
                  >
                    <RefreshCw size={13} />
                    RE-ALIGN
                  </button>

                  {/* Toggle Active State */}
                  <button
                    onClick={() => onToggleAgentStatus(agent.id)}
                    className={`px-3 py-2 rounded-lg text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                      isActive 
                        ? 'bg-brand-error/10 border border-brand-error/20 text-brand-error hover:bg-brand-error/20' 
                        : 'bg-brand-primary text-brand-bg hover:opacity-90'
                    }`}
                  >
                    {isActive ? (
                      <>
                        <Pause size={13} />
                        DEACTIVATE
                      </>
                    ) : (
                      <>
                        <Play size={13} />
                        ACTIVATE
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Telemetry Metrics */}
              <div className="grid grid-cols-3 gap-4 border-t border-white/5 pt-4 z-10">
                <div>
                  <span className="font-mono text-[9px] text-brand-outline tracking-wider uppercase block mb-0.5">PROCESSED</span>
                  <span className="font-display text-lg font-bold text-brand-text">{agent.processedCount}</span>
                </div>
                <div>
                  <span className="font-mono text-[9px] text-brand-outline tracking-wider uppercase block mb-0.5">HEURISTIC ACCURACY</span>
                  <span className="font-display text-lg font-bold text-brand-success">{agent.accuracy}</span>
                </div>
                <div>
                  <span className="font-mono text-[9px] text-brand-outline tracking-wider uppercase block mb-0.5">CLUSTER ID</span>
                  <span className="font-mono text-xs text-brand-text block mt-1">NODE_US_E_0{agent.id.slice(-1)}</span>
                </div>
              </div>

              {/* Sparkline Canvas Area */}
              <div className="space-y-1 z-10">
                <span className="font-mono text-[9px] text-brand-outline tracking-wider uppercase">Active Inference Sparkline</span>
                <div className="h-14 w-full">
                  <svg className="w-full h-full" preserveAspectRatio="none" viewBox="0 0 100 30">
                    <defs>
                      <linearGradient id={`sparkline-gradient-${agent.id}`} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={isActive ? '#c0c1ff' : '#908fa0'} stopOpacity="0.4" />
                        <stop offset="100%" stopColor={isActive ? '#c0c1ff' : '#908fa0'} stopOpacity="0" />
                      </linearGradient>
                    </defs>
                    <path
                      d={agent.sparklineData.reduce((acc, val, i) => {
                        const x = (i / (agent.sparklineData.length - 1)) * 100;
                        const y = 30 - val;
                        return acc + `${i === 0 ? 'M' : 'L'}${x},${y}`;
                      }, '')}
                      fill="none"
                      stroke={isActive ? '#4cd7f6' : '#908fa0'}
                      strokeWidth="2"
                      strokeLinecap="round"
                    />
                    <path
                      d={agent.sparklineData.reduce((acc, val, i) => {
                        const x = (i / (agent.sparklineData.length - 1)) * 100;
                        const y = 30 - val;
                        return acc + `${i === 0 ? 'M' : 'L'}${x},${y}`;
                      }, '') + ' L100,30 L0,30 Z'}
                      fill={`url(#sparkline-gradient-${agent.id})`}
                    />
                  </svg>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Initialize Agent placeholder CTA */}
      <button 
        onClick={onInitializeAgent}
        className="w-full py-6 border-2 border-dashed border-white/10 hover:border-brand-primary/50 hover:bg-brand-primary/5 rounded-xl flex flex-col items-center justify-center gap-2 transition-all group cursor-pointer"
      >
        <Sparkles size={24} className="text-brand-primary group-hover:scale-110 transition-transform" />
        <span className="font-mono text-sm font-semibold text-brand-text">Deploy Additional Agent Node</span>
      </button>
    </div>
  );
}
