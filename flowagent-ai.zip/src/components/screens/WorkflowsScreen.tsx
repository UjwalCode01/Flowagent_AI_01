/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Bot, 
  Cpu, 
  Clock, 
  ChevronRight, 
  Search, 
  Plus, 
  Trash2, 
  Calendar, 
  AlertTriangle,
  Sparkles,
  ArrowRightLeft
} from 'lucide-react';
import { Task, TaskCategory, TaskStatus } from '../../types';

interface WorkflowsScreenProps {
  tasks: Task[];
  onAddTaskClick: () => void;
  onUpdateTaskStatus: (taskId: string, newStatus: TaskStatus) => void;
  onDeleteTask: (taskId: string) => void;
}

export default function WorkflowsScreen({ tasks, onAddTaskClick, onUpdateTaskStatus, onDeleteTask }: WorkflowsScreenProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');

  // Filter tasks based on query and category
  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          task.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'ALL' || task.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const columns: Array<{ id: TaskStatus; label: string; dotColor: string }> = [
    { id: 'in-progress', label: 'In Progress', dotColor: 'bg-brand-secondary shadow-[0_0_8px_rgba(76,215,246,0.6)]' },
    { id: 'to-do', label: 'To Do', dotColor: 'bg-brand-outline' },
    { id: 'completed', label: 'Completed', dotColor: 'bg-brand-success shadow-[0_0_8px_rgba(16,185,129,0.6)]' },
  ];

  const getTaskIcon = (category: TaskCategory) => {
    switch (category) {
      case 'AGENT_EXECUTION':
        return <Bot size={14} className="text-brand-primary" />;
      case 'SYSTEM_IDLE':
        return <Cpu size={14} className="text-brand-warning" />;
      default:
        return <Clock size={14} className="text-brand-muted" />;
    }
  };

  const advanceTask = (taskId: string, currentStatus: TaskStatus) => {
    if (currentStatus === 'to-do') {
      onUpdateTaskStatus(taskId, 'in-progress');
    } else if (currentStatus === 'in-progress') {
      onUpdateTaskStatus(taskId, 'completed');
    } else {
      onUpdateTaskStatus(taskId, 'to-do');
    }
  };

  return (
    <div className="space-y-6">
      {/* Search and Filters panel */}
      <div className="glass-card p-4 rounded-xl flex flex-col sm:flex-row gap-3">
        {/* Search input */}
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-outline" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search workflows, nodes, and objectives..."
            className="w-full h-10 bg-brand-bg/80 border border-white/10 rounded-lg pl-9 pr-4 text-brand-text placeholder:text-brand-outline/50 focus:outline-none focus:border-brand-secondary text-sm"
          />
        </div>
        
        {/* Category selector */}
        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="h-10 bg-[#171f33] border border-white/10 rounded-lg px-3 text-brand-text focus:outline-none focus:border-brand-secondary text-sm"
        >
          <option value="ALL">All Categories</option>
          <option value="AGENT_EXECUTION">Agent Execution</option>
          <option value="SYSTEM_IDLE">System Idle</option>
          <option value="UI_AUDIT">UI Audit</option>
        </select>

        {/* Create button */}
        <button
          onClick={onAddTaskClick}
          className="h-10 bg-brand-primary text-brand-bg px-4 rounded-lg font-mono text-[12px] font-bold flex items-center justify-center gap-1.5 hover:opacity-90 active:scale-95 transition-all"
        >
          <Plus size={16} />
          ADD WORKFLOW
        </button>
      </div>

      {/* Pipeline columns */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {columns.map((column) => {
          const colTasks = filteredTasks.filter(t => t.status === column.id);

          return (
            <div key={column.id} className="space-y-4">
              {/* Column Header */}
              <div className="flex items-center justify-between pb-2 border-b border-white/5">
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${column.dotColor}`} />
                  <h3 className="font-display font-semibold text-brand-text">{column.label}</h3>
                  <span className="bg-white/5 px-2 py-0.5 rounded text-[11px] font-mono text-brand-muted">
                    {colTasks.length}
                  </span>
                </div>
              </div>

              {/* Task list container */}
              <div className="space-y-3 min-h-[150px]">
                {colTasks.length === 0 ? (
                  <div className="h-28 border border-dashed border-white/5 rounded-xl flex items-center justify-center text-center p-4">
                    <p className="font-sans text-xs text-brand-outline italic">No active workflows in this stage</p>
                  </div>
                ) : (
                  colTasks.map((task) => (
                    <div
                      key={task.id}
                      className="glass-card p-4 rounded-xl flex flex-col gap-3 hover:border-white/20 transition-all duration-300 relative group overflow-hidden"
                    >
                      {/* Interactive glowing left bar based on status */}
                      <div className={`absolute left-0 top-0 bottom-0 w-1 ${
                        column.id === 'in-progress' ? 'bg-brand-secondary' :
                        column.id === 'completed' ? 'bg-brand-success' : 'bg-brand-outline'
                      }`} />

                      {/* Header block */}
                      <div className="flex justify-between items-start pl-2">
                        <div className="flex items-center gap-2">
                          <span className="bg-white/5 text-[10px] font-mono text-brand-muted px-2 py-0.5 rounded border border-white/5 flex items-center gap-1">
                            {getTaskIcon(task.category)}
                            {task.categoryLabel || task.category.replace('_', ' ')}
                          </span>
                        </div>
                        
                        {/* Quick action triggers */}
                        <div className="flex items-center gap-1.5 opacity-65 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => advanceTask(task.id, task.status)}
                            title="Advance Pipeline Status"
                            className="p-1 rounded text-brand-muted hover:text-brand-secondary hover:bg-white/5 transition-all"
                          >
                            <ArrowRightLeft size={13} />
                          </button>
                          <button
                            onClick={() => onDeleteTask(task.id)}
                            title="Delete Workflow"
                            className="p-1 rounded text-brand-muted hover:text-brand-error hover:bg-white/5 transition-all"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>

                      {/* Title & Body */}
                      <div className="pl-2">
                        <h4 className="font-display font-semibold text-[15px] text-brand-text mb-1 leading-snug">
                          {task.title}
                        </h4>
                        <p className="font-sans text-xs text-brand-muted line-clamp-2">
                          {task.description}
                        </p>
                      </div>

                      {/* Footer block (Assignees, tags, and actions) */}
                      <div className="flex items-center justify-between pt-3 pl-2 border-t border-white/5">
                        <div className="flex items-center gap-2">
                          {/* Assignees avatars list */}
                          {task.assignees && task.assignees.length > 0 ? (
                            <div className="flex -space-x-2">
                              {task.assignees.map((assignee, i) => (
                                <div key={i} className="w-6 h-6 rounded-full border border-[#171f33] overflow-hidden bg-brand-primary/20 flex items-center justify-center">
                                  {assignee.avatarUrl ? (
                                    <img 
                                      src={assignee.avatarUrl} 
                                      alt={assignee.name} 
                                      className="w-full h-full object-cover"
                                      referrerPolicy="no-referrer"
                                    />
                                  ) : (
                                    <span className="font-mono text-[8px] font-bold text-brand-bg">AI</span>
                                  )}
                                </div>
                              ))}
                            </div>
                          ) : (
                            <span className="font-mono text-[9px] text-brand-outline italic">unassigned</span>
                          )}
                        </div>

                        {/* Status/Deadline indicators */}
                        <div className="flex items-center gap-3 font-mono text-[10px] text-brand-outline">
                          {task.remainingTime && (
                            <div className="flex items-center gap-1 text-brand-secondary">
                              <Clock size={11} />
                              <span>{task.remainingTime}</span>
                            </div>
                          )}
                          {task.priority && (
                            <div className="flex items-center gap-1 text-brand-warning">
                              <AlertTriangle size={11} />
                              <span>{task.priority}</span>
                            </div>
                          )}
                          {task.deadline && (
                            <div className="flex items-center gap-1">
                              <Calendar size={11} />
                              <span>{task.deadline}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom Floating Action FAB for Workflows */}
      <button 
        onClick={onAddTaskClick}
        className="fixed bottom-24 right-6 md:bottom-8 md:right-8 w-14 h-14 rounded-full bg-brand-primary text-brand-bg shadow-xl shadow-brand-primary/30 flex items-center justify-center z-50 hover:scale-105 active:scale-90 transition-all cursor-pointer"
      >
        <Plus size={28} />
      </button>
    </div>
  );
}
