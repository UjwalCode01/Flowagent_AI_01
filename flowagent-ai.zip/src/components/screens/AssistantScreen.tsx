/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { 
  Sparkles, 
  Send, 
  User, 
  Bot, 
  SearchCode, 
  Flame, 
  Wand2, 
  Sliders, 
  HelpCircle 
} from 'lucide-react';
import { ChatMessage } from '../../types';
import { AVATARS, SUGGESTED_PROMPTS } from '../../data';

interface AssistantScreenProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  isTyping: boolean;
}

export default function AssistantScreen({ messages, onSendMessage, isTyping }: AssistantScreenProps) {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    onSendMessage(inputText);
    setInputText('');
  };

  const handleSuggestedPromptClick = (prompt: string) => {
    onSendMessage(prompt);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-14rem)] md:h-[calc(100vh-10rem)] max-w-2xl mx-auto">
      {/* Top Navigation Anchor / Chat Header inside main panel */}
      <div className="flex justify-between items-center px-4 py-3 bg-white/5 border border-white/10 rounded-xl mb-4">
        <div className="flex items-center gap-3">
          <span className="p-1.5 rounded-lg bg-brand-primary/10 text-brand-primary">
            <Sparkles size={16} />
          </span>
          <div>
            <h3 className="font-display font-semibold text-sm text-brand-text">FlowAgent Intelligence</h3>
            <p className="font-mono text-[9px] text-brand-success uppercase font-bold tracking-wider">Syncing Q3 Pipeline</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-brand-muted hover:text-brand-text transition-all">
            <Sliders size={16} />
          </button>
          <div className="w-8 h-8 rounded-full overflow-hidden border border-white/10">
            <img 
              src={AVATARS.executiveOffice} 
              alt="User executive headshot" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </div>

      {/* Main Messages Canvas */}
      <div className="flex-1 overflow-y-auto no-scrollbar space-y-6 pb-4 pr-1">
        {messages.map((message) => {
          const isAssistant = message.sender === 'assistant';
          const isSystem = message.sender === 'system';
          const isUser = message.sender === 'user';

          return (
            <div key={message.id} className="flex gap-4 items-start animate-in fade-in slide-in-from-bottom-2 duration-300">
              {/* Avatar indicator */}
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-1 ${
                isAssistant ? 'bg-brand-primary/10 text-brand-primary' :
                isSystem ? 'bg-brand-secondary/10 text-brand-secondary animate-pulse' :
                'bg-white/10 text-brand-text'
              }`}>
                {isAssistant && <Bot size={18} />}
                {isSystem && <SearchCode size={18} />}
                {isUser && <User size={18} />}
              </div>

              {/* Message text / component */}
              <div className="space-y-2 flex-1 min-w-0">
                <p className={`font-mono text-[9px] uppercase tracking-wider ${
                  isAssistant ? 'text-brand-primary' :
                  isSystem ? 'text-brand-secondary font-bold' :
                  'text-brand-muted'
                }`}>
                  {message.senderLabel} • {message.timestamp}
                </p>

                {isSystem && message.processingDetails ? (
                  <div className="space-y-3">
                    <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-brand-primary to-brand-secondary w-2/3" />
                    </div>
                    <div className="p-4 rounded-xl glass-panel space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-sans text-xs font-bold text-brand-text">
                          {message.processingDetails.title}
                        </span>
                        <span className="px-2 py-0.5 rounded bg-brand-error/20 text-brand-error text-[9px] font-mono font-bold uppercase">
                          {message.processingDetails.riskLevel}
                        </span>
                      </div>
                      <p className="font-sans text-xs text-brand-muted leading-relaxed">
                        {message.processingDetails.description}
                      </p>
                      <button className="px-3 py-1.5 rounded-lg bg-brand-secondary/10 border border-brand-secondary/20 text-brand-secondary font-mono text-[11px] font-bold hover:bg-brand-secondary/20 transition-all cursor-pointer">
                        {message.processingDetails.actionLabel}
                      </button>
                    </div>
                  </div>
                ) : (
                  <p className="font-sans text-xs md:text-sm text-brand-text leading-relaxed whitespace-pre-line">
                    {message.text}
                  </p>
                )}
              </div>
            </div>
          );
        })}

        {/* Typing Animation */}
        {isTyping && (
          <div className="flex gap-4 items-center py-2 opacity-80 animate-pulse">
            <div className="w-8 h-8 rounded-lg bg-brand-primary/5 flex items-center justify-center flex-shrink-0">
              <Wand2 size={16} className="text-brand-primary/40 animate-spin" />
            </div>
            <div className="flex gap-1.5 items-center">
              <span className="font-mono text-[11px] text-brand-outline italic">AI is syncing parameters</span>
              <div className="flex gap-1 ml-1">
                <div className="w-1 h-1 rounded-full bg-brand-primary animate-bounce" />
                <div className="w-1.5 h-1.5 rounded-full bg-brand-primary animate-bounce delay-150" />
                <div className="w-1 h-1 rounded-full bg-brand-primary animate-bounce delay-300" />
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompts & Input Box Area */}
      <div className="space-y-3 pt-2 bg-brand-bg/95 relative z-20">
        {/* Suggested pills */}
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
          {SUGGESTED_PROMPTS.map((prompt, i) => (
            <button
              key={i}
              onClick={() => handleSuggestedPromptClick(prompt)}
              className="flex-shrink-0 px-3.5 py-1.5 rounded-full border border-white/5 bg-white/5 text-brand-muted font-mono text-[10px] hover:border-brand-primary/40 hover:text-brand-text transition-all whitespace-nowrap cursor-pointer"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <form onSubmit={handleSubmit} className="relative group">
          <div className="absolute -inset-0.5 bg-gradient-to-r from-brand-primary/20 to-brand-secondary/20 rounded-xl blur opacity-30 group-focus-within:opacity-100 transition duration-500" />
          <div className="relative flex items-center bg-[#171f33] rounded-xl border border-white/10 px-4 py-1 focus-within:border-brand-secondary transition-all">
            <Sparkles className="text-brand-outline mr-3" size={16} />
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask FlowAgent..."
              className="flex-1 bg-transparent border-none text-brand-text placeholder:text-brand-outline/50 focus:ring-0 font-sans text-sm py-3.5 focus:outline-none"
            />
            <button
              type="submit"
              disabled={!inputText.trim()}
              className={`w-10 h-10 rounded-lg flex items-center justify-center transition-all ${
                inputText.trim() 
                  ? 'bg-brand-primary text-brand-bg shadow-lg shadow-brand-primary/20 active:scale-95' 
                  : 'bg-white/5 text-brand-outline cursor-not-allowed'
              }`}
            >
              <Send size={16} />
            </button>
          </div>
        </form>

        {/* Metadata Label */}
        <div className="flex justify-center">
          <p className="font-mono text-[9px] text-brand-outline/60 uppercase tracking-widest">
            FlowAgent Engine v2.4.0 • Enterprise Core
          </p>
        </div>
      </div>
    </div>
  );
}
