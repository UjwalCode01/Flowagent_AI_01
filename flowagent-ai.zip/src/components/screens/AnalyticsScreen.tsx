/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { LineChart, BarChart2, Shield, Activity, TrendingUp, Cpu, Info } from 'lucide-react';
import { DashboardStats } from '../../types';

interface AnalyticsScreenProps {
  stats: DashboardStats;
}

export default function AnalyticsScreen({ stats }: AnalyticsScreenProps) {
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  // 7 days productivity stats
  const chartData = [
    { day: 'Mon', value: 40, efficiency: '78%' },
    { day: 'Tue', value: 48, efficiency: '81%' },
    { day: 'Wed', value: 42, efficiency: '79%' },
    { day: 'Thu', value: 68, efficiency: '88%' },
    { day: 'Fri', value: 60, efficiency: '84%' },
    { day: 'Sat', value: 85, efficiency: '95%' },
    { day: 'Sun', value: 94, efficiency: '99%' },
  ];

  // Calculate SVG line points based on data values (canvas width: 100, canvas height: 30)
  const maxVal = 100;
  const pointsStr = chartData.map((d, i) => {
    const x = (i / (chartData.length - 1)) * 500; // 500px width
    const y = 180 - (d.value / maxVal) * 150;     // 180px height scale
    return { x, y, day: d.day, value: d.value, efficiency: d.efficiency };
  });

  const pathD = pointsStr.reduce((acc, p, i) => acc + `${i === 0 ? 'M' : 'L'}${p.x},${p.y}`, '');
  const areaD = `${pathD} L500,180 L0,180 Z`;

  return (
    <div className="space-y-6">
      {/* Analytics header context */}
      <section className="flex flex-col gap-1">
        <p className="font-mono text-[10px] text-brand-secondary uppercase tracking-widest mb-1">
          Live Environment
        </p>
        <h2 className="font-display text-2xl font-bold text-brand-text leading-tight">
          System <span className="text-brand-secondary">Analytics</span>
        </h2>
        <div className="flex items-center gap-2 mt-1">
          <span className="w-2 h-2 rounded-full bg-brand-success animate-pulse" />
          <span className="font-sans text-xs text-brand-muted">Heuristics Engine running nominally • v2.4.0</span>
        </div>
      </section>

      {/* Grid of stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="glass-card p-5 rounded-xl flex flex-col gap-1">
          <span className="font-mono text-[10px] text-brand-outline tracking-wider uppercase">EFFICIENCY</span>
          <span className="font-display text-2xl font-bold text-brand-primary">{stats.efficiency}</span>
          <p className="font-sans text-[11px] text-brand-muted mt-1 flex items-center gap-1">
            <TrendingUp size={12} className="text-brand-success" />
            Relative to Q2 Baseline
          </p>
        </div>
        <div className="glass-card p-5 rounded-xl flex flex-col gap-1">
          <span className="font-mono text-[10px] text-brand-outline tracking-wider uppercase">ACTIVE AGENTS</span>
          <span className="font-display text-2xl font-bold text-brand-secondary">{stats.activeAgentsCount}</span>
          <p className="font-sans text-[11px] text-brand-muted mt-1 flex items-center gap-1">
            <Cpu size={12} className="text-brand-secondary" />
            Distributed cluster nodes
          </p>
        </div>
      </div>

      {/* Main Productivity Interactive SVG Area Chart */}
      <section className="space-y-4">
        <div className="flex justify-between items-end">
          <div>
            <h3 className="font-display text-base font-bold text-brand-text">Productivity</h3>
            <p className="font-mono text-[10px] text-brand-outline uppercase">Last 7 days output</p>
          </div>
          <span className="font-mono text-[9px] text-brand-outline uppercase border border-white/10 px-2 py-0.5 rounded">
            Unit: GigaFLOP/s
          </span>
        </div>

        <div className="glass-card p-5 rounded-xl">
          {/* Main SVG Area Chart */}
          <div className="relative w-full h-48 mt-4">
            {/* Grid horizontal markers */}
            <div className="absolute inset-0 flex flex-col justify-between pointer-events-none opacity-10">
              <div className="border-t border-white w-full h-0" />
              <div className="border-t border-white w-full h-0" />
              <div className="border-t border-white w-full h-0" />
              <div className="border-t border-white w-full h-0" />
            </div>

            <svg className="w-full h-full" viewBox="0 0 500 180" preserveAspectRatio="none">
              <defs>
                <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#c0c1ff" stopOpacity="0.45" />
                  <stop offset="100%" stopColor="#4cd7f6" stopOpacity="0" />
                </linearGradient>
              </defs>

              {/* Area filled path */}
              <path d={areaD} fill="url(#areaGradient)" />

              {/* Stroke line path */}
              <path d={pathD} fill="none" stroke="#4cd7f6" strokeWidth="3" strokeLinecap="round" />

              {/* Render glowing dots on mouse-over */}
              {pointsStr.map((p, idx) => (
                <g key={idx} className="cursor-pointer">
                  {/* Invisible hover capture zone */}
                  <circle
                    cx={p.x}
                    cy={p.y}
                    r="15"
                    fill="transparent"
                    onMouseEnter={() => setHoverIndex(idx)}
                    onMouseLeave={() => setHoverIndex(null)}
                  />
                  {/* Visual circle marker */}
                  <circle
                    cx={p.x}
                    cy={p.y}
                    r={hoverIndex === idx ? "6" : "3"}
                    fill={hoverIndex === idx ? "#c0c1ff" : "#4cd7f6"}
                    className="transition-all duration-200"
                    stroke="#0b1326"
                    strokeWidth="1.5"
                  />
                </g>
              ))}
            </svg>

            {/* Float Tooltip */}
            {hoverIndex !== null && (
              <div 
                className="absolute bg-[#171f33] border border-brand-secondary/30 rounded-lg p-2.5 shadow-xl pointer-events-none flex flex-col gap-0.5 z-20 transition-all duration-200"
                style={{
                  left: `${(hoverIndex / (chartData.length - 1)) * 80 + 5}%`,
                  top: `${pointsStr[hoverIndex].y - 70}px`
                }}
              >
                <span className="font-mono text-[9px] text-brand-secondary uppercase font-bold tracking-wider">
                  {pointsStr[hoverIndex].day} telemetry
                </span>
                <span className="font-sans text-xs text-brand-text font-semibold">
                  Volume: {pointsStr[hoverIndex].value} GFLOPS
                </span>
                <span className="font-sans text-[10px] text-brand-success font-semibold">
                  Optimization: {pointsStr[hoverIndex].efficiency}
                </span>
              </div>
            )}
          </div>

          {/* Days Labels Row */}
          <div className="flex justify-between mt-3 px-1 font-mono text-[10px] text-brand-outline">
            {chartData.map((d, i) => (
              <span key={i} className={hoverIndex === i ? 'text-brand-primary font-bold' : ''}>
                {d.day}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* System Integrity list */}
      <section className="space-y-3">
        <h3 className="font-display text-sm font-bold text-brand-text uppercase tracking-wider pl-1">
          Infrastructure Diagnostics
        </h3>
        <div className="glass-card rounded-xl overflow-hidden divide-y divide-white/5">
          <div className="p-4 flex justify-between items-center text-xs">
            <span className="text-brand-muted flex items-center gap-1.5">
              <Shield size={14} className="text-brand-success" /> Security Verification
            </span>
            <span className="font-mono text-brand-success">100% VALIDATED</span>
          </div>
          <div className="p-4 flex justify-between items-center text-xs">
            <span className="text-brand-muted flex items-center gap-1.5">
              <Activity size={14} className="text-brand-secondary" /> Microservice Latency
            </span>
            <span className="font-mono text-brand-secondary">14ms average</span>
          </div>
        </div>
      </section>
    </div>
  );
}
