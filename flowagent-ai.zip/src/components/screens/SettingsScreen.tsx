/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Moon, 
  Sun, 
  Sliders, 
  Brain, 
  HelpCircle, 
  CheckCircle, 
  LogOut, 
  Edit2, 
  ChevronRight,
  Slack,
  GitBranch,
  Settings,
  Bot
} from 'lucide-react';
import { AVATARS } from '../../data';

interface SettingsScreenProps {
  onLogout: () => void;
}

export default function SettingsScreen({ onLogout }: SettingsScreenProps) {
  const [darkTheme, setDarkTheme] = useState(true);
  const [sensitivity, setSensitivity] = useState(80);
  const [autoPilot, setAutoPilot] = useState(false);
  const [jiraLinked, setJiraLinked] = useState(false);
  const [isLinkingJira, setIsLinkingJira] = useState(false);

  // Determine sensitivity text label
  const getSensitivityLabel = (val: number) => {
    if (val < 30) return 'Low';
    if (val < 70) return 'Medium';
    if (val < 90) return 'High';
    return 'Autonomous';
  };

  const toggleTheme = () => {
    setDarkTheme(!darkTheme);
    // Directly toggle document class for premium dark mode interaction!
    const htmlElement = document.documentElement;
    if (darkTheme) {
      htmlElement.classList.remove('dark');
    } else {
      htmlElement.classList.add('dark');
    }
  };

  const handleLinkJira = () => {
    if (jiraLinked) {
      setJiraLinked(false);
      return;
    }
    setIsLinkingJira(true);
    setTimeout(() => {
      setIsLinkingJira(false);
      setJiraLinked(true);
    }, 1500);
  };

  return (
    <div className="space-y-6 max-w-md mx-auto">
      {/* Profile summary card */}
      <section className="glass-card rounded-xl p-5 flex items-center gap-4 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-brand-primary/5 rounded-full blur-2xl pointer-events-none" />
        <div className="relative">
          <img 
            src={AVATARS.charcoalBlazer} 
            alt="Executive developer headshot" 
            className="w-16 h-16 rounded-full object-cover border-2 border-brand-primary/20"
            referrerPolicy="no-referrer"
          />
          <div className="absolute bottom-0 right-0 w-4 h-4 bg-brand-success border-2 border-[#131b2e] rounded-full" />
        </div>
        <div className="flex flex-col min-w-0">
          <h2 className="font-display font-bold text-lg text-brand-text truncate">FlowAgent AI</h2>
          <span className="font-sans text-xs text-brand-muted">Enterprise Account</span>
          <span className="font-mono text-[10px] text-brand-secondary mt-0.5">Console Version: v2.4.0</span>
        </div>
        <button className="ml-auto p-2 rounded-lg bg-white/5 border border-white/5 text-brand-muted hover:text-brand-primary hover:bg-white/10 transition-colors">
          <Edit2 size={14} />
        </button>
      </section>

      {/* Main Settings lists */}
      <div className="space-y-4">
        {/* Appearance block */}
        <div className="space-y-1.5">
          <p className="font-mono text-[9px] text-brand-outline uppercase tracking-wider pl-1 font-bold">Appearance</p>
          <div className="glass-card rounded-xl overflow-hidden divide-y divide-white/5">
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3 text-brand-text text-sm">
                <Moon size={18} className="text-brand-secondary animate-pulse" />
                <span>Dark Theme Canvas</span>
              </div>
              <button 
                onClick={toggleTheme}
                className={`w-11 h-6 rounded-full p-0.5 transition-all cursor-pointer ${
                  darkTheme ? 'bg-brand-primary' : 'bg-white/10'
                }`}
              >
                <div className={`w-5 h-5 rounded-full bg-brand-bg transition-all ${
                  darkTheme ? 'translate-x-5' : 'translate-x-0'
                }`} />
              </button>
            </div>
          </div>
        </div>

        {/* AI preferences block */}
        <div className="space-y-1.5">
          <p className="font-mono text-[9px] text-brand-outline uppercase tracking-wider pl-1 font-bold">AI Preferences</p>
          <div className="glass-card rounded-xl overflow-hidden divide-y divide-white/5 p-4 space-y-4">
            
            {/* Optimization Sensitivity Slider */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 text-brand-text text-sm">
                  <Brain size={18} className="text-brand-primary" />
                  <span>Heuristic Sensitivity</span>
                </div>
                <span className="font-mono text-xs font-bold text-brand-primary">
                  {getSensitivityLabel(sensitivity)} ({sensitivity}%)
                </span>
              </div>
              <input 
                type="range"
                min="10"
                max="100"
                value={sensitivity}
                onChange={(e) => setSensitivity(Number(e.target.value))}
                className="w-full h-1.5 bg-white/5 rounded-lg appearance-none cursor-pointer accent-brand-primary"
              />
              <p className="font-sans text-[11px] text-brand-muted leading-relaxed">
                Determines how aggressively the AI restructures your active workflows and reallocates agent nodes.
              </p>
            </div>

            {/* Auto Pilot Toggle */}
            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-3 text-brand-text text-sm">
                <Settings size={18} className="text-brand-secondary" />
                <span>Auto-Pilot Optimization Mode</span>
              </div>
              <button 
                onClick={() => setAutoPilot(!autoPilot)}
                className={`w-11 h-6 rounded-full p-0.5 transition-all cursor-pointer ${
                  autoPilot ? 'bg-brand-primary' : 'bg-white/10'
                }`}
              >
                <div className={`w-5 h-5 rounded-full bg-brand-bg transition-all ${
                  autoPilot ? 'translate-x-5' : 'translate-x-0'
                }`} />
              </button>
            </div>
          </div>
        </div>

        {/* Integrations block */}
        <div className="space-y-1.5">
          <p className="font-mono text-[9px] text-brand-outline uppercase tracking-wider pl-1 font-bold">Connected Platforms</p>
          <div className="glass-card rounded-xl overflow-hidden divide-y divide-white/5">
            {/* Slack */}
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-[#4A154B] flex items-center justify-center text-white">
                  <Slack size={16} />
                </div>
                <div>
                  <p className="font-sans text-xs font-bold text-brand-text">Slack Communications</p>
                  <p className="font-mono text-[10px] text-brand-success">Connected</p>
                </div>
              </div>
              <ChevronRight size={16} className="text-brand-outline" />
            </div>

            {/* Jira */}
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-[#0052CC] flex items-center justify-center text-white">
                  <span className="font-display font-bold text-sm">J</span>
                </div>
                <div>
                  <p className="font-sans text-xs font-bold text-brand-text">Jira Software Tickets</p>
                  <p className={`font-mono text-[10px] ${jiraLinked ? 'text-brand-success' : 'text-brand-outline'}`}>
                    {jiraLinked ? 'Connected' : 'Not Linked'}
                  </p>
                </div>
              </div>
              <button 
                onClick={handleLinkJira}
                disabled={isLinkingJira}
                className={`px-3 py-1 font-mono text-[10px] font-bold rounded-lg border transition-all cursor-pointer ${
                  isLinkingJira ? 'bg-white/5 border-white/10 text-brand-outline cursor-wait' :
                  jiraLinked 
                    ? 'bg-brand-error/10 border-brand-error/20 text-brand-error hover:bg-brand-error/20' 
                    : 'bg-brand-primary/10 border-brand-primary/20 text-brand-primary hover:bg-brand-primary/20'
                }`}
              >
                {isLinkingJira ? 'LINKING...' : jiraLinked ? 'DISCONNECT' : 'LINK'}
              </button>
            </div>

            {/* GitHub */}
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-[#24292F] flex items-center justify-center text-white border border-white/10">
                  <GitBranch size={16} />
                </div>
                <div>
                  <p className="font-sans text-xs font-bold text-brand-text">GitHub Repositories</p>
                  <p className="font-mono text-[10px] text-brand-success">Connected</p>
                </div>
              </div>
              <ChevronRight size={16} className="text-brand-outline" />
            </div>
          </div>
        </div>

        {/* Danger zone logouts */}
        <div className="pt-4">
          <button 
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 p-4 text-brand-error bg-brand-error/10 border border-brand-error/20 hover:bg-brand-error/20 rounded-xl active:scale-[0.98] transition-transform font-mono text-xs font-bold uppercase tracking-wider cursor-pointer"
          >
            <LogOut size={16} />
            Logout Session
          </button>
        </div>
      </div>
    </div>
  );
}
