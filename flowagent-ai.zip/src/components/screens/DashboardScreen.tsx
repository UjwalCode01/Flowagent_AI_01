/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Bot, Cpu, ShieldAlert, Clock, PlusCircle, ArrowUpRight, TrendingUp, Sparkles } from 'lucide-react';
import { Agent, DashboardStats } from '../../types';
import { AVATARS } from '../../data';

interface DashboardScreenProps {
  stats: DashboardStats;
  agents: Agent[];
  onNavigateToTab: (tab: string) => void;
  onInitializeAgent: () => void;
}

export default function DashboardScreen({ stats, agents, onNavigateToTab, onInitializeAgent }: DashboardScreenProps) {
  return (
    <div className="space-y-6">
      {/* Hero Welcome Banner */}
      <section className="flex flex-col gap-1">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-brand-success animate-pulse" />
          <span className="font-mono text-[11px] text-brand-success font-semibold tracking-wider uppercase">
            SYSTEMS NOMINAL
          </span>
        </div>
        <h2 className="font-display text-2xl md:text-3xl font-bold text-brand-text leading-tight">
          Active Intelligence <br className="sm:hidden" />
          <span className="text-brand-secondary">Orchestration</span>
        </h2>
        <p className="font-sans text-sm text-brand-muted mt-1 max-w-xl">
          Managing {agents.length} distributed agents across enterprise infrastructure. Click on agents to monitor telemetry.
        </p>
      </section>

      {/* Stats Quick Look (Bento Grid) */}
      <div className="grid grid-cols-2 gap-4">
        <div className="glass-card p-5 rounded-xl flex flex-col gap-1 hover:border-brand-primary/30 transition-all cursor-pointer" onClick={() => onNavigateToTab('analytics')}>
          <span className="font-mono text-[10px] text-brand-outline tracking-wider uppercase">GLOBAL ACCURACY</span>
          <span className="font-display text-2xl font-bold text-brand-primary">{stats.globalAccuracy}</span>
        </div>
        <div className="glass-card p-5 rounded-xl flex flex-col gap-1 hover:border-brand-secondary/30 transition-all cursor-pointer" onClick={() => onNavigateToTab('analytics')}>
          <span className="font-mono text-[10px] text-brand-outline tracking-wider uppercase">UPTIME</span>
          <span className="font-display text-2xl font-bold text-brand-secondary">{stats.uptime}</span>
        </div>
      </div>

      {/* AI Agent Cards Grid */}
      <section className="space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="font-display text-lg font-bold text-brand-text">Agent Roster</h3>
          <button 
            onClick={() => onNavigateToTab('agents')}
            className="font-mono text-[11px] text-brand-secondary hover:underline flex items-center gap-1"
          >
            VIEW DETAILS <ArrowUpRight size={14} />
          </button>
        </div>

        <div className="space-y-3">
          {agents.map((agent) => {
            const isTaskAssign = agent.iconType === 'assignment';
            const isRiskDetect = agent.iconType === 'security';
            const isDeadlineOpt = agent.iconType === 'schedule';

            const isActive = agent.status === 'Active';

            return (
              <div 
                key={agent.id} 
                className={`glass-card p-5 rounded-xl flex flex-col gap-4 relative overflow-hidden transition-all hover:scale-[1.01] ${
                  isActive ? 'border-brand-primary/30 shadow-[0_0_15px_rgba(192,193,255,0.1)]' : ''
                }`}
              >
                {/* Active pulse effect */}
                {isActive && (
                  <div className="absolute inset-0 bg-gradient-to-r from-brand-secondary/5 via-transparent to-transparent pointer-events-none" />
                )}

                <div className="flex justify-between items-start z-10">
                  <div className="flex items-center gap-3">
                    <div className={`p-2.5 rounded-xl border ${
                      isTaskAssign ? 'bg-brand-primary/10 border-brand-primary/20 text-brand-primary' :
                      isRiskDetect ? 'bg-brand-error/10 border-brand-error/20 text-brand-error' :
                      'bg-brand-secondary/10 border-brand-secondary/20 text-brand-secondary'
                    }`}>
                      {isTaskAssign && <Bot size={18} />}
                      {isRiskDetect && <Cpu size={18} />}
                      {isDeadlineOpt && <Clock size={18} />}
                    </div>
                    <div>
                      <h4 className="font-sans text-sm font-semibold text-brand-text">{agent.name}</h4>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        {isActive ? (
                          <>
                            <span className="w-1.5 h-1.5 rounded-full bg-brand-primary animate-ping" />
                            <span className="font-mono text-[9px] text-brand-primary uppercase font-bold tracking-wider">Active</span>
                          </>
                        ) : (
                          <>
                            <span className="w-1.5 h-1.5 rounded-full bg-brand-outline" />
                            <span className="font-mono text-[9px] text-brand-outline uppercase font-bold tracking-wider">Idle</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                  <span className="font-mono text-[10px] text-brand-outline font-bold"> telemetry live </span>
                </div>

                <div className="grid grid-cols-2 gap-4 z-10">
                  <div className="flex flex-col">
                    <span className="font-mono text-[10px] text-brand-outline uppercase tracking-wider">
                      {isTaskAssign ? 'PROCESSED' : isRiskDetect ? 'SCANNED' : 'RE-SCHEDULED'}
                    </span>
                    <span className="font-display text-xl font-bold text-brand-text">{agent.processedCount}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-mono text-[10px] text-brand-outline uppercase tracking-wider">ACCURACY</span>
                    <span className="font-display text-xl font-bold text-brand-success">{agent.accuracy}</span>
                  </div>
                </div>

                {/* Animated Sparkline Graphic */}
                <div className="h-14 w-full mt-2 z-10">
                  <svg className="w-full h-full" preserveAspectRatio="none" viewBox="0 0 100 30">
                    <defs>
                      <linearGradient id={`gradient-${agent.id}`} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={isActive ? '#c0c1ff' : '#908fa0'} stopOpacity="0.4" />
                        <stop offset="100%" stopColor={isActive ? '#c0c1ff' : '#908fa0'} stopOpacity="0" />
                      </linearGradient>
                    </defs>
                    <path
                      d={agent.sparklineData.reduce((acc, val, i) => {
                        const x = (i / (agent.sparklineData.length - 1)) * 100;
                        const y = 30 - val;
                        return acc + `${i === 0 ? 'M' : 'L'}${x},${y}`;
                      }, '')}
                      fill="none"
                      stroke={isActive ? '#4cd7f6' : '#908fa0'}
                      strokeWidth="2"
                      strokeLinecap="round"
                    />
                    {/* Fill Area */}
                    <path
                      d={agent.sparklineData.reduce((acc, val, i) => {
                        const x = (i / (agent.sparklineData.length - 1)) * 100;
                        const y = 30 - val;
                        return acc + `${i === 0 ? 'M' : 'L'}${x},${y}`;
                      }, '') + ` L100,30 L0,30 Z`}
                      fill={`url(#gradient-${agent.id})`}
                    />
                  </svg>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* New Agent Placeholder CTA */}
      <button 
        onClick={onInitializeAgent}
        className="w-full py-6 border-2 border-dashed border-white/10 hover:border-brand-primary/50 hover:bg-brand-primary/5 rounded-xl flex flex-col items-center justify-center gap-2 transition-all group cursor-pointer"
      >
        <PlusCircle size={24} className="text-brand-primary group-hover:scale-110 transition-transform" />
        <span className="font-mono text-sm font-semibold text-brand-text">Initialize New AI Agent</span>
      </button>

      {/* Inline Dashboard Footer */}
      <footer className="w-full pt-6 border-t border-white/10 flex flex-col items-center gap-4 text-center">
        <span className="font-display font-bold text-lg text-brand-text">FlowAgent AI</span>
        <div className="flex gap-6">
          <button onClick={() => onNavigateToTab('assistant')} className="font-mono text-xs text-brand-outline hover:text-brand-text transition-colors">Documentation</button>
          <button onClick={() => onNavigateToTab('settings')} className="font-mono text-xs text-brand-outline hover:text-brand-text transition-colors">Privacy Policy</button>
          <button onClick={() => onNavigateToTab('innovation')} className="font-mono text-xs text-brand-outline hover:text-brand-text transition-colors flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-brand-success" /> System Status
          </button>
        </div>
        <p className="font-mono text-[10px] text-brand-outline">© 2026 FlowAgent AI. All rights reserved.</p>
      </footer>
    </div>
  );
}
